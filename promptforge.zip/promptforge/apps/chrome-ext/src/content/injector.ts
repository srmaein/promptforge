interface PlatformConfig {
  textareaSelector: string;
  platform: string;
}

const PLATFORMS: Record<string, PlatformConfig> = {
  'chat.openai.com':     { textareaSelector: '#prompt-textarea', platform: 'ChatGPT' },
  'chatgpt.com':         { textareaSelector: '#prompt-textarea', platform: 'ChatGPT' },
  'claude.ai':           { textareaSelector: 'div[contenteditable="true"]', platform: 'Claude' },
  'gemini.google.com':   { textareaSelector: '.ql-editor', platform: 'Gemini' },
};

function debounce<T extends (...args: unknown[]) => void>(fn: T, wait: number): T {
  let timer: ReturnType<typeof setTimeout>;
  return ((...args: unknown[]) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), wait); }) as T;
}

const hostname = window.location.hostname;
const config = Object.entries(PLATFORMS).find(([domain]) => hostname.includes(domain))?.[1];
if (config) init(config);

function init(cfg: PlatformConfig) {
  const observe = debounce(() => {
    const el = document.querySelector<HTMLElement>(cfg.textareaSelector);
    if (el && !document.getElementById('pf-forge-btn')) injectButton(el, cfg);
  }, 300);
  new MutationObserver(observe).observe(document.body, { subtree: true, childList: true });
}

function injectButton(el: HTMLElement, cfg: PlatformConfig) {
  const btn = document.createElement('button');
  btn.id = 'pf-forge-btn';
  btn.textContent = '⚡ Forge';
  btn.title = 'Optimize with PromptForge';
  Object.assign(btn.style, {
    position: 'absolute', bottom: '12px', right: '52px',
    background: '#7c3aed', color: '#fff', border: 'none',
    borderRadius: '6px', padding: '4px 10px', fontSize: '13px',
    fontWeight: '600', cursor: 'pointer', zIndex: '9999',
    fontFamily: 'system-ui, sans-serif',
  });

  btn.onclick = async (e) => {
    e.preventDefault();
    const text = (el as HTMLTextAreaElement).value || el.textContent || '';
    if (!text.trim()) return;

    btn.textContent = '⚡ Forging…';
    btn.setAttribute('disabled', 'true');

    const res = await chrome.runtime.sendMessage({ type: 'OPTIMIZE', prompt: text, model: 'general' });

    if (res.success && res.data) {
      const { optimized, savingsPct, score } = res.data as { optimized: string; savingsPct: number; score: number };
      if ((el as HTMLTextAreaElement).value !== undefined) {
        (el as HTMLTextAreaElement).value = optimized;
        el.dispatchEvent(new Event('input', { bubbles: true }));
      } else {
        el.textContent = optimized;
      }
      showToast(`⚡ −${Math.round(savingsPct)}% tokens · Score ${score}`);
    } else if (res.error === 'NOT_AUTHENTICATED') {
      chrome.runtime.sendMessage({ type: 'OPEN_POPUP' });
    }

    btn.textContent = '⚡ Forge';
    btn.removeAttribute('disabled');
  };

  const parent = el.parentElement;
  if (parent) { parent.style.position = 'relative'; parent.appendChild(btn); }
}

function showToast(msg: string) {
  const toast = document.createElement('div');
  toast.textContent = msg;
  Object.assign(toast.style, {
    position: 'fixed', bottom: '20px', right: '20px',
    background: '#059669', color: '#fff', padding: '8px 16px',
    borderRadius: '8px', fontSize: '13px', fontWeight: '600',
    zIndex: '99999', fontFamily: 'system-ui, sans-serif',
    boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
  });
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'SHOW_OPTIMIZER' && msg.selectedText) {
    const el = document.querySelector<HTMLElement>(Object.values(PLATFORMS).find(p => true)?.textareaSelector ?? '');
    if (el) {
      if ((el as HTMLTextAreaElement).value !== undefined) (el as HTMLTextAreaElement).value = msg.selectedText;
      else el.textContent = msg.selectedText;
    }
  }
});
