export async function getAuthToken(): Promise<string | null> {
  const { auth_token } = await chrome.storage.local.get('auth_token');
  return auth_token ?? null;
}

export async function setAuthToken(token: string): Promise<void> {
  await chrome.storage.local.set({ auth_token: token });
}

export async function clearAuthToken(): Promise<void> {
  await chrome.storage.local.remove('auth_token');
}

export async function getSettings(): Promise<{ defaultModel: string; autoOptimize: boolean }> {
  const result = await chrome.storage.sync.get({ defaultModel: 'general', autoOptimize: false });
  return result as { defaultModel: string; autoOptimize: boolean };
}

export async function saveSettings(settings: Partial<{ defaultModel: string; autoOptimize: boolean }>): Promise<void> {
  await chrome.storage.sync.set(settings);
}
