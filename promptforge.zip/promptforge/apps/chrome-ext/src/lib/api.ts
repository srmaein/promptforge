const API_BASE = 'https://promptforge.ai';

export interface OptimizeResponse {
  optimized: string;
  savingsPct: number;
  score: number;
  originalTokens: number;
  optimizedTokens: number;
}

export class PromptForgeAPI {
  async optimize(params: {
    prompt: string;
    targetModel: string;
    token: string;
  }): Promise<OptimizeResponse> {
    const response = await fetch(`${API_BASE}/api/forge`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${params.token}`,
      },
      body: JSON.stringify({ prompt: params.prompt, targetModel: params.targetModel }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(err.error ?? 'Optimization failed');
    }

    // Parse SSE stream
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let result: OptimizeResponse | null = null;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const text = decoder.decode(value);
      for (const line of text.split('\n').filter(l => l.startsWith('data: '))) {
        const data = JSON.parse(line.slice(6));
        if (data.type === 'result') result = data.data;
        if (data.type === 'error') throw new Error(data.message);
      }
    }

    if (!result) throw new Error('No result received');
    return result;
  }

  async getUser(token: string): Promise<{ email: string; plan: string; usage: { used: number; limit: number } }> {
    const [userRes, usageRes] = await Promise.all([
      fetch(`${API_BASE}/api/auth/me`, { headers: { 'Authorization': `Bearer ${token}` } }),
      fetch(`${API_BASE}/api/usage`, { headers: { 'Authorization': `Bearer ${token}` } }),
    ]);
    const user = await userRes.json();
    const usage = await usageRes.json();
    return { ...user, usage };
  }
}
