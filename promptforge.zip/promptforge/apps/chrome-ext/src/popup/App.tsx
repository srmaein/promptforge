import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { getAuthToken } from '../lib/storage';

interface User { email: string; plan: string; usage: { used: number; limit: number } }

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const token = await getAuthToken();
      if (token) {
        const res = await chrome.runtime.sendMessage({ type: 'GET_USER' });
        if (res.success) setUser(res.data as User);
      }
      setLoading(false);
    }
    load();
  }, []);

  if (loading) return <div style={{ padding: 24, textAlign: 'center' }}>Loading…</div>;

  if (!user) return (
    <div style={{ padding: 24, textAlign: 'center' }}>
      <div style={{ fontSize: 24, marginBottom: 8 }}>⚡</div>
      <div style={{ fontSize: 18, fontWeight: 700, color: '#8b5cf6', marginBottom: 4 }}>PromptForge</div>
      <p style={{ fontSize: 12, color: '#9ca3af', marginBottom: 16 }}>Sign in to optimize prompts</p>
      <a href="https://promptforge.ai/login" target="_blank" rel="noopener noreferrer"
        style={{ display: 'inline-block', padding: '10px 24px', background: '#7c3aed', color: '#fff', borderRadius: 8, textDecoration: 'none', fontSize: 13, fontWeight: 600 }}>
        Sign In
      </a>
    </div>
  );

  const usagePct = Math.round((user.usage.used / user.usage.limit) * 100);

  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <span style={{ fontSize: 16, fontWeight: 700, color: '#8b5cf6' }}>⚡ PromptForge</span>
        <span style={{ fontSize: 11, padding: '2px 8px', background: '#4c1d95', color: '#c4b5fd', borderRadius: 20, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          {user.plan}
        </span>
      </div>
      <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 8 }}>{user.email}</div>
      <div style={{ marginBottom: 4, display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
        <span style={{ color: '#9ca3af' }}>Usage</span>
        <span style={{ color: '#e5e7eb' }}>{user.usage.used} / {user.usage.limit}</span>
      </div>
      <div style={{ height: 4, background: '#1f2937', borderRadius: 4 }}>
        <div style={{ height: '100%', width: `${usagePct}%`, background: usagePct >= 90 ? '#ef4444' : '#7c3aed', borderRadius: 4 }}/>
      </div>
      <p style={{ marginTop: 16, fontSize: 11, color: '#6b7280', textAlign: 'center' }}>
        Click ⚡ Forge button in any AI chat to optimize
      </p>
    </div>
  );
}

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
