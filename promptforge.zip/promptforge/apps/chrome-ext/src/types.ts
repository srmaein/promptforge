export interface ExtMessage {
  type: 'OPTIMIZE' | 'GET_USER' | 'SET_TOKEN' | 'SIGN_OUT' | 'OPEN_POPUP' | 'SHOW_OPTIMIZER';
  prompt?: string;
  model?: string;
  token?: string;
  selectedText?: string;
}

export interface ExtResponse {
  success: boolean;
  data?: unknown;
  error?: string;
}
