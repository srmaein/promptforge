import { PromptForgeAPI } from '../lib/api';
import { getAuthToken, setAuthToken, clearAuthToken } from '../lib/storage';
import type { ExtMessage, ExtResponse } from '../types';

const api = new PromptForgeAPI();

chrome.runtime.onMessage.addListener(
  (message: ExtMessage, _sender, sendResponse: (r: ExtResponse) => void) => {
    handleMessage(message).then(sendResponse).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  },
);

async function handleMessage(message: ExtMessage): Promise<ExtResponse> {
  switch (message.type) {
    case 'OPTIMIZE': {
      const token = await getAuthToken();
      if (!token) return { success: false, error: 'NOT_AUTHENTICATED' };
      const result = await api.optimize({
        prompt: message.prompt!,
        targetModel: message.model ?? 'general',
        token,
      });
      return { success: true, data: result };
    }
    case 'GET_USER': {
      const token = await getAuthToken();
      if (!token) return { success: false, error: 'NOT_AUTHENTICATED' };
      const user = await api.getUser(token);
      return { success: true, data: user };
    }
    case 'SET_TOKEN':
      await setAuthToken(message.token!);
      return { success: true };
    case 'SIGN_OUT':
      await clearAuthToken();
      return { success: true };
    default:
      return { success: false, error: 'Unknown message type' };
  }
}

// Context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'promptforge-optimize',
    title: '⚡ Optimize with PromptForge',
    contexts: ['selection'],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'promptforge-optimize' && info.selectionText && tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'SHOW_OPTIMIZER', selectedText: info.selectionText });
  }
});
