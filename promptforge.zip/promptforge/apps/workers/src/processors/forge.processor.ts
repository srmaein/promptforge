import type { Job } from 'bullmq';
import { promptOptimizer } from '@promptforge/ai-engine';
import { saveOptimization, incrementUsage, getMonthKey, checkReferralActivation } from '@promptforge/db';
import { analyticsQueue } from '@promptforge/queue';
import { logger } from '@promptforge/logger';
import type { ForgeJobData } from '@promptforge/types';
import type { TargetModel } from '@promptforge/config';

export async function forgeProcessor(job: Job<ForgeJobData>): Promise<void> {
  const { prompt, targetModel, userId, plan } = job.data;
  logger.info({ event: 'forge_job_start', jobId: job.id, userId });

  await job.updateProgress(10);

  const result = await promptOptimizer.optimize({
    prompt,
    targetModel: targetModel as TargetModel,
    userId,
    tier: plan,
  });

  await job.updateProgress(80);

  if (!result.fromCache) {
    await saveOptimization({ userId, originalPrompt: prompt, targetModel, result });
    await incrementUsage(userId, getMonthKey());
  }

  await job.updateProgress(90);

  await analyticsQueue.add('analytics', {
    event: 'optimization_complete',
    userId,
    properties: { model: targetModel, savingsPct: result.savingsPct, score: result.score, plan },
  });

  await checkReferralActivation(userId);
  await job.updateProgress(100);

  logger.info({ event: 'forge_job_complete', jobId: job.id, userId, score: result.score });
}
