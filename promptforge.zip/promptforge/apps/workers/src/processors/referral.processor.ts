import type { Job } from 'bullmq';
import { checkReferralActivation, db } from '@promptforge/db';
import { emailQueue } from '@promptforge/queue';
import { logger } from '@promptforge/logger';
import type { ReferralJobData } from '@promptforge/types';

export async function referralProcessor(job: Job<ReferralJobData>): Promise<void> {
  const { userId, action } = job.data;

  if (action === 'check_activation') {
    // Before checking, see if reward was just granted
    const { data: before } = await db
      .from('referral_events')
      .select('referrer_id, reward_value')
      .eq('referred_id', userId)
      .eq('reward_granted', true)
      .maybeSingle();

    const hadRewardBefore = !!before;
    await checkReferralActivation(userId);

    // After check, see if a new reward was just created
    if (!hadRewardBefore) {
      const { data: after } = await db
        .from('referral_events')
        .select('referrer_id, reward_value')
        .eq('referred_id', userId)
        .eq('reward_granted', true)
        .maybeSingle();

      // Reward was just granted — send email to referrer
      if (after?.referrer_id) {
        await emailQueue.add('email', {
          type: 'referral_reward',
          userId: after.referrer_id,
          metadata: { creditsGranted: after.reward_value ?? 50 },
        }).catch(() => null);

        logger.info({ event: 'referral_email_queued', referrerId: after.referrer_id });
      }
    }
  }
}
