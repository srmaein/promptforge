import type { Job } from 'bullmq';
import { track } from '@promptforge/analytics';
import { logger } from '@promptforge/logger';
import type { AnalyticsJobData } from '@promptforge/types';
import type { AnalyticsEvent } from '@promptforge/analytics';

export async function analyticsProcessor(job: Job<AnalyticsJobData>): Promise<void> {
  const { event, userId, properties } = job.data;
  track(userId, event as AnalyticsEvent, properties);
  logger.debug({ event: 'analytics_tracked', analyticsEvent: event, userId });
}
