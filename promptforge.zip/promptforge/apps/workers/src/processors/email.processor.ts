import type { Job } from 'bullmq';
import { logger } from '@promptforge/logger';
import { db } from '@promptforge/db';
import type { EmailJobData } from '@promptforge/types';

// Resend email client
async function sendEmail(to: string, subject: string, html: string) {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM ?? 'noreply@promptforge.ai',
      to,
      subject,
      html,
    }),
  });
  if (!res.ok) throw new Error(`Email send failed: ${await res.text()}`);
}

const EMAIL_TEMPLATES: Record<EmailJobData['type'], (meta: Record<string, unknown>) => { subject: string; html: string }> = {
  welcome: () => ({
    subject: '⚡ Welcome to PromptForge!',
    html: '<h1>Welcome!</h1><p>You have 25 free optimizations this month. <a href="https://promptforge.ai/dashboard/forge">Start forging</a>.</p>',
  }),
  subscription_canceled: () => ({
    subject: 'Your PromptForge Pro subscription has been canceled',
    html: '<p>Your subscription has been canceled. You\'ll keep Pro access until the end of your billing period.</p>',
  }),
  payment_receipt: (meta) => ({
    subject: 'PromptForge — Payment Receipt',
    html: `<p>Payment received. Invoice ID: ${meta.invoiceId}.</p>`,
  }),
  payment_failed: () => ({
    subject: 'Action required: PromptForge payment failed',
    html: '<p>Your last payment failed. Please update your payment method to keep your Pro access.</p>',
  }),
  referral_reward: (meta) => ({
    subject: `🎁 You earned ${meta.creditsGranted} free optimizations!`,
    html: `<p>Your referral activated! You both earned ${meta.creditsGranted} free optimizations.</p>`,
  }),
  usage_limit_warning: () => ({
    subject: 'You\'re approaching your PromptForge usage limit',
    html: '<p>You\'ve used 80% of your monthly optimizations. Upgrade to Pro for 500/month.</p>',
  }),
};

export async function emailProcessor(job: Job<EmailJobData>): Promise<void> {
  const { type, userId, metadata = {} } = job.data;
  logger.info({ event: 'email_job_start', jobId: job.id, type, userId });

  const { data: user } = await db.from('users').select('email').eq('id', userId).single();
  if (!user?.email) { logger.warn({ event: 'email_user_not_found', userId }); return; }

  const template = EMAIL_TEMPLATES[type];
  if (!template) { logger.warn({ event: 'email_template_not_found', type }); return; }

  const { subject, html } = template(metadata);
  await sendEmail(user.email, subject, html);
  logger.info({ event: 'email_sent', type, userId });
}
