import { Worker } from 'bullmq';
import { getConnection } from '@promptforge/queue';
import { logger } from '@promptforge/logger';
import { forgeProcessor } from './processors/forge.processor';
import { emailProcessor } from './processors/email.processor';
import { analyticsProcessor } from './processors/analytics.processor';
import { referralProcessor } from './processors/referral.processor';

const connection = getConnection();

const workers = [
  new Worker('forge', forgeProcessor, {
    connection,
    concurrency: Number(process.env.WORKER_CONCURRENCY ?? 5),
    limiter: { max: 10, duration: 1000 },
  }),
  new Worker('email', emailProcessor, { connection, concurrency: 20 }),
  new Worker('analytics', analyticsProcessor, { connection, concurrency: 50 }),
  new Worker('referral', referralProcessor, { connection, concurrency: 10 }),
];

workers.forEach(worker => {
  worker.on('completed', job => {
    logger.info({ event: 'job_completed', queue: worker.name, jobId: job.id });
  });
  worker.on('failed', (job, err) => {
    logger.error({ event: 'job_failed', queue: worker.name, jobId: job?.id, err });
  });
  worker.on('stalled', jobId => {
    logger.warn({ event: 'job_stalled', queue: worker.name, jobId });
  });
});

async function gracefulShutdown(signal: string) {
  logger.info({ event: 'shutdown_signal', signal });
  await Promise.all(workers.map(w => w.close()));
  await connection.quit();
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

logger.info({ event: 'workers_started', queues: workers.map(w => w.name) });
