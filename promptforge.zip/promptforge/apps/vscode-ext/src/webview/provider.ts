import * as vscode from 'vscode';

export class PromptForgeWebviewProvider implements vscode.WebviewViewProvider {
  static readonly viewType = 'promptforge.sidebar';

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly secrets: vscode.SecretStorage,
  ) {}

  async resolveWebviewView(webviewView: vscode.WebviewView) {
    webviewView.webview.options = { enableScripts: true };

    const token = await this.secrets.get('promptforge.token');
    webviewView.webview.html = this.getHtml(!!token);

    webviewView.webview.onDidReceiveMessage(async (msg) => {
      if (msg.type === 'SIGN_IN') {
        await vscode.env.openExternal(vscode.Uri.parse('https://promptforge.ai/vscode-connect'));
      }
      if (msg.type === 'SET_TOKEN') {
        await this.secrets.store('promptforge.token', msg.token);
        webviewView.webview.html = this.getHtml(true);
      }
      if (msg.type === 'SIGN_OUT') {
        await this.secrets.delete('promptforge.token');
        webviewView.webview.html = this.getHtml(false);
      }
    });
  }

  async promptSignIn() {
    await vscode.env.openExternal(vscode.Uri.parse('https://promptforge.ai/vscode-connect'));
  }

  private getHtml(isSignedIn: boolean): string {
    return `<!DOCTYPE html>
<html>
<head>
<style>
  body { font-family: var(--vscode-font-family); padding: 16px; color: var(--vscode-foreground); background: var(--vscode-editor-background); }
  button { background: #7c3aed; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600; width: 100%; }
  .tip { font-size: 11px; color: var(--vscode-descriptionForeground); margin-top: 12px; line-height: 1.6; }
</style>
</head>
<body>
  <div style="font-size:18px;font-weight:700;color:#8b5cf6;margin-bottom:12px">⚡ PromptForge</div>
  ${isSignedIn
    ? `<p style="font-size:12px;margin-bottom:12px">Signed in ✓</p>
       <p class="tip">Select any prompt text and press <strong>Ctrl+Shift+P</strong> to optimize it, or right-click and choose "Optimize with PromptForge".</p>
       <button onclick="vscode.postMessage({type:'SIGN_OUT'})" style="margin-top:12px;background:#374151">Sign Out</button>`
    : `<p style="font-size:12px;margin-bottom:12px">Sign in to optimize prompts</p>
       <button onclick="vscode.postMessage({type:'SIGN_IN'})">Sign In to PromptForge</button>
       <p class="tip">After signing in, paste your API token here:</p>
       <input id="token" placeholder="Paste token…" style="width:100%;margin-top:8px;padding:6px;background:var(--vscode-input-background);border:1px solid var(--vscode-input-border);color:var(--vscode-input-foreground);border-radius:4px;font-size:12px"/>
       <button onclick="document.getElementById('token').value && vscode.postMessage({type:'SET_TOKEN',token:document.getElementById('token').value})" style="margin-top:8px">Connect</button>`
  }
  <script>const vscode = acquireVsCodeApi();</script>
</body>
</html>`;
  }
}
