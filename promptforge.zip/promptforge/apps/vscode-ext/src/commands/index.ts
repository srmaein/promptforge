import * as vscode from 'vscode';
import type { PromptForgeWebviewProvider } from '../webview/provider';

const API_BASE = 'https://promptforge.ai';

export async function optimizeSelection(
  provider: PromptForgeWebviewProvider,
  secrets: vscode.SecretStorage,
): Promise<void> {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showErrorMessage('No active editor');
    return;
  }

  const selection = editor.selection;
  if (selection.isEmpty) {
    vscode.window.showWarningMessage('Select the prompt text you want to optimize');
    return;
  }

  const selectedText = editor.document.getText(selection);
  if (selectedText.trim().length < 10) {
    vscode.window.showWarningMessage('Selection too short');
    return;
  }

  const token = await secrets.get('promptforge.token');
  if (!token) {
    vscode.window.showErrorMessage('Please sign in to PromptForge first', 'Sign In').then(action => {
      if (action === 'Sign In') vscode.commands.executeCommand('promptforge.signIn');
    });
    return;
  }

  const config = vscode.workspace.getConfiguration('promptforge');
  const model = config.get<string>('defaultModel', 'general');

  await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: '⚡ PromptForge optimizing…', cancellable: false },
    async () => {
      try {
        const result = await callForgeAPI(selectedText, model, token);
        await editor.edit(eb => eb.replace(selection, result.optimized));
        vscode.window.showInformationMessage(
          `⚡ Optimized! −${Math.round(result.savingsPct)}% tokens · Score ${result.score}/100`,
        );
      } catch (err) {
        vscode.window.showErrorMessage(`Optimization failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
      }
    },
  );
}

async function callForgeAPI(prompt: string, model: string, token: string) {
  const res = await fetch(`${API_BASE}/api/forge`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ prompt, targetModel: model }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error ?? 'Request failed');
  }

  const reader = res.body?.getReader();
  if (!reader) throw new Error('No response body');
  const decoder = new TextDecoder();
  let result: { optimized: string; savingsPct: number; score: number } | null = null;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const text = decoder.decode(value);
    for (const line of text.split('\n').filter(l => l.startsWith('data: '))) {
      const data = JSON.parse(line.slice(6));
      if (data.type === 'result') result = data.data;
      if (data.type === 'error') throw new Error(data.message);
    }
  }
  if (!result) throw new Error('No result received');
  return result;
}
