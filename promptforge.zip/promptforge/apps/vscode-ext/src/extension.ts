import * as vscode from 'vscode';
import { optimizeSelection } from './commands';
import { PromptForgeWebviewProvider } from './webview/provider';

export function activate(context: vscode.ExtensionContext) {
  // Register sidebar webview
  const provider = new PromptForgeWebviewProvider(context.extensionUri, context.secrets);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(PromptForgeWebviewProvider.viewType, provider),
  );

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('promptforge.optimizeSelection', () =>
      optimizeSelection(provider, context.secrets),
    ),
    vscode.commands.registerCommand('promptforge.signIn', () =>
      provider.promptSignIn(),
    ),
  );

  // Register code action for .md and .txt files
  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      [{ pattern: '**/*.{md,txt,prompt}' }, { language: 'markdown' }],
      {
        provideCodeActions(doc, range) {
          if (range.isEmpty) return [];
          const action = new vscode.CodeAction(
            '⚡ Optimize with PromptForge',
            vscode.CodeActionKind.Refactor,
          );
          action.command = { command: 'promptforge.optimizeSelection', title: 'Optimize' };
          return [action];
        },
      },
    ),
  );

  vscode.window.showInformationMessage('PromptForge activated! Select text and press Ctrl+Shift+P to optimize.');
}

export function deactivate() {}
