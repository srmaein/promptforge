import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'PromptForge — Optimize AI Prompts, Reduce Token Waste',
};

const STATS = [
  { value: '40%', label: 'Average token reduction' },
  { value: '92', label: 'Average quality score' },
  { value: '50ms', label: 'Median response time' },
  { value: '12+', label: 'AI models supported' },
];

const FEATURES = [
  {
    icon: '⚡',
    title: 'Token-Efficient Optimization',
    description: 'Our AI engine compresses prompts by 20–40% without losing intent. Save money on API calls at scale.',
  },
  {
    icon: '🎯',
    title: 'Model-Specific Structuring',
    description: 'GPT-4o, Claude, and Gemini each respond to different structures. PromptForge knows the difference.',
  },
  {
    icon: '📊',
    title: 'Quality Scoring',
    description: 'Every optimized prompt gets a score based on clarity, structure, completeness, and efficiency.',
  },
  {
    icon: '🔗',
    title: 'One-Click Sharing',
    description: 'Share optimized prompts as public pages. Indexed by Google — your prompts drive organic traffic.',
  },
  {
    icon: '🧩',
    title: 'Chrome Extension',
    description: 'Optimize prompts directly in ChatGPT, Claude.ai, and Gemini. One click inside any AI interface.',
  },
  {
    icon: '📚',
    title: 'Template Marketplace',
    description: 'Browse and publish optimized prompt templates by category, model, and use case.',
  },
];

export default function HomePage() {
  return (
    <div className="flex flex-col items-center">
      {/* Hero */}
      <section className="w-full max-w-6xl mx-auto px-6 pt-24 pb-16 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-violet-50 dark:bg-violet-900/20 text-violet-700 dark:text-violet-300 text-sm font-medium mb-6 border border-violet-200 dark:border-violet-800">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75"/>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-violet-500"/>
          </span>
          Now supporting Gemini 2.0 & Claude 3.5
        </div>
        <h1 className="text-5xl sm:text-6xl font-bold tracking-tight text-gray-900 dark:text-white mb-6 text-balance">
          Stop wasting tokens.
          <br />
          <span className="text-violet-600">Start writing better prompts.</span>
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-10 text-balance">
          PromptForge transforms vague, bloated prompts into structured, token-efficient AI prompts — optimized for ChatGPT, Claude, Gemini, and 12+ other models.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/signup"
            className="px-8 py-4 bg-violet-600 hover:bg-violet-700 text-white font-semibold rounded-xl transition-all shadow-lg shadow-violet-200 dark:shadow-violet-900/30 text-lg"
          >
            Start Forging Free
          </Link>
          <Link
            href="/dashboard/forge"
            className="px-8 py-4 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-900 dark:text-white font-semibold rounded-xl transition-all text-lg"
          >
            Try a Demo →
          </Link>
        </div>
        <p className="mt-4 text-sm text-gray-500">Free forever · No credit card required · 25 optimizations/month</p>
      </section>

      {/* Stats */}
      <section className="w-full max-w-4xl mx-auto px-6 pb-16">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          {STATS.map((stat) => (
            <div key={stat.label} className="text-center p-4 rounded-2xl bg-gray-50 dark:bg-gray-900">
              <div className="text-3xl font-bold text-violet-600 dark:text-violet-400">{stat.value}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="w-full max-w-6xl mx-auto px-6 pb-24">
        <h2 className="text-3xl font-bold text-center mb-12">Everything your prompts need</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((f) => (
            <div key={f.title} className="p-6 rounded-2xl border border-gray-200 dark:border-gray-800 hover:border-violet-300 dark:hover:border-violet-700 transition-colors bg-white dark:bg-gray-900">
              <div className="text-2xl mb-3">{f.icon}</div>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{f.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{f.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="w-full bg-violet-600 dark:bg-violet-800">
        <div className="max-w-3xl mx-auto px-6 py-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to forge better prompts?</h2>
          <p className="text-violet-100 mb-8">Join thousands of engineers and creators getting more from every AI interaction.</p>
          <Link href="/signup" className="inline-block px-8 py-4 bg-white text-violet-700 font-bold rounded-xl hover:bg-violet-50 transition-colors text-lg">
            Get Started Free
          </Link>
        </div>
      </section>
    </div>
  );
}
