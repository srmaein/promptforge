import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = { title: 'Pricing' };

const PLANS = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Get started with prompt optimization at no cost.',
    features: [
      '25 optimizations/month',
      '3 AI models (GPT-3.5, Gemini Flash)',
      '7-day history',
      'Quality scoring',
      'Template marketplace (read)',
    ],
    cta: 'Get Started Free',
    href: '/signup',
    highlight: false,
  },
  {
    name: 'Pro',
    price: '$12',
    period: '/month',
    description: 'For power users and prompt engineers.',
    trial: '7-day free trial',
    features: [
      '500 optimizations/month',
      'All 12 AI models',
      'Unlimited history',
      'Public share pages',
      'Template publishing',
      'Priority email support',
    ],
    cta: 'Start Free Trial',
    href: '/signup?plan=pro',
    highlight: true,
  },
  {
    name: 'Team',
    price: '$49',
    period: '/month',
    description: 'For teams building AI products.',
    features: [
      'Unlimited optimizations',
      'All models + early access',
      'API access',
      'Priority queue',
      'Bulk export',
      'Team management',
      'SLA support',
    ],
    cta: 'Start Free Trial',
    href: '/signup?plan=team',
    highlight: false,
  },
];

export default function PricingPage() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-24">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Simple, transparent pricing</h1>
        <p className="text-xl text-gray-500 dark:text-gray-400">Start free. Upgrade when you need more.</p>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {PLANS.map(plan => (
          <div key={plan.name} className={`rounded-2xl border p-8 flex flex-col ${plan.highlight ? 'border-violet-400 dark:border-violet-600 bg-violet-50 dark:bg-violet-900/20 shadow-lg shadow-violet-100 dark:shadow-violet-900/20' : 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900'}`}>
            {plan.highlight && <div className="text-xs font-semibold text-violet-600 uppercase tracking-widest mb-4">Most Popular</div>}
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{plan.name}</h3>
            <div className="mt-2 mb-1">
              <span className="text-4xl font-bold text-gray-900 dark:text-white">{plan.price}</span>
              <span className="text-gray-500 dark:text-gray-400 text-sm">{plan.period}</span>
            </div>
            {plan.trial && <div className="text-xs text-violet-600 font-medium mb-3">{plan.trial}</div>}
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">{plan.description}</p>
            <ul className="space-y-2.5 mb-8 flex-1">
              {plan.features.map(f => (
                <li key={f} className="flex items-start gap-2.5 text-sm text-gray-700 dark:text-gray-300">
                  <span className="text-green-500 mt-0.5 shrink-0">✓</span>{f}
                </li>
              ))}
            </ul>
            <Link href={plan.href}
              className={`w-full py-3 text-center text-sm font-semibold rounded-xl transition-colors ${plan.highlight ? 'bg-violet-600 hover:bg-violet-700 text-white' : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-900 dark:text-white'}`}>
              {plan.cta}
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
