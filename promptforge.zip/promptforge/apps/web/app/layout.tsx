import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? 'https://promptforge.ai'),
  title: {
    default: 'PromptForge — AI Prompt Optimizer',
    template: '%s | PromptForge',
  },
  description: 'Transform messy prompts into structured, token-efficient AI prompts. Reduce token waste by up to 40% for GPT-4, Claude, Gemini, and more.',
  keywords: ['prompt engineering', 'AI prompts', 'prompt optimization', 'ChatGPT', 'Claude', 'Gemini', 'token reduction'],
  authors: [{ name: 'PromptForge' }],
  creator: 'PromptForge',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: process.env.NEXT_PUBLIC_APP_URL,
    siteName: 'PromptForge',
    title: 'PromptForge — AI Prompt Optimizer',
    description: 'Transform messy prompts into structured, token-efficient AI prompts.',
    images: [{ url: '/og-default.png', width: 1200, height: 630, alt: 'PromptForge' }],
  },
  twitter: {
    card: 'summary_large_image',
    creator: '@promptforge',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${jetbrainsMono.variable} font-sans antialiased bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100`}>
        {children}
      </body>
    </html>
  );
}
