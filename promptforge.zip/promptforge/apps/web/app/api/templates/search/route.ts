import { NextRequest, NextResponse } from 'next/server';
import { db } from '@promptforge/db';
import { cache } from '@promptforge/redis';
import { generateEmbedding } from '@promptforge/ai-engine';

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const q = url.searchParams.get('q') ?? '';
  const category = url.searchParams.get('category');
  const model = url.searchParams.get('model');
  const page = Number(url.searchParams.get('page') ?? 1);

  if (!q || q.length < 2) {
    return NextResponse.json({ error: 'Query too short' }, { status: 400 });
  }

  const cacheKey = `search:${q}:${category}:${model}:${page}`;
  const cached = await cache.get(cacheKey);
  if (cached) return NextResponse.json(cached);

  const embedding = await generateEmbedding(q);
  const { data, error } = await db.rpc('search_templates', {
    query_embedding: embedding as unknown as string,
    query_text: q,
    filter_category: category ?? null,
    filter_model: model ?? null,
    page_offset: (page - 1) * 20,
    page_limit: 20,
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const result = { templates: data, page, query: q };
  await cache.set(cacheKey, result, 300);
  return NextResponse.json(result);
}
