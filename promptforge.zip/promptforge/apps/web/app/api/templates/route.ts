import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { db } from '@promptforge/db';
import { handleApiError, AuthError } from '@promptforge/errors';
import { generateEmbedding } from '@promptforge/ai-engine';

const CreateTemplateSchema = z.object({
  title: z.string().min(5).max(100),
  description: z.string().min(10).max(500),
  template_body: z.string().min(20).max(10_000),
  variables: z.array(z.object({ name: z.string(), description: z.string(), required: z.boolean() })).default([]),
  category: z.string(),
  target_models: z.array(z.string()).default([]),
  tags: z.array(z.string()).default([]),
  slug: z.string().min(3).max(80).regex(/^[a-z0-9-]+$/),
});

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const category = url.searchParams.get('category');
  const featured = url.searchParams.get('featured') === 'true';
  const limit = Math.min(Number(url.searchParams.get('limit') ?? 20), 50);

  let query = db.from('templates').select('*').eq('is_published', true).order('use_count', { ascending: false }).limit(limit);
  if (category) query = query.eq('category', category);
  if (featured) query = query.eq('is_featured', true);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ templates: data });
}

export async function POST(req: NextRequest) {
  try {
    const body = CreateTemplateSchema.parse(await req.json());
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new AuthError();

    const embedding = await generateEmbedding(`${body.title} ${body.description} ${body.template_body}`);

    const { data, error } = await db.from('templates').insert({
      ...body,
      author_id: user.id,
      embedding: embedding as unknown as string,
    }).select().single();

    if (error) throw new Error(error.message);
    return NextResponse.json({ template: data }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
