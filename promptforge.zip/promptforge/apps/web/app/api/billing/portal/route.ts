import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createPortalSession } from '@promptforge/stripe';
import { db } from '@promptforge/db';
import { handleApiError, AuthError } from '@promptforge/errors';

export async function POST(req: Request) {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new AuthError();
    const { data: userData } = await db.from('users').select('stripe_customer_id').eq('id', user.id).single();
    if (!userData?.stripe_customer_id) return NextResponse.redirect(new URL('/pricing', req.url));
    const returnUrl = `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/settings`;
    const portalUrl = await createPortalSession(userData.stripe_customer_id, returnUrl);
    return NextResponse.redirect(portalUrl);
  } catch (err) {
    return handleApiError(err);
  }
}
