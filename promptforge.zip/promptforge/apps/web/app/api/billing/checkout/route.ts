import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createCheckoutSession } from '@promptforge/stripe';
import { handleApiError, AuthError } from '@promptforge/errors';

const CheckoutSchema = z.object({ priceId: z.string().startsWith('price_') });

export async function POST(req: NextRequest) {
  try {
    const { priceId } = CheckoutSchema.parse(await req.json());
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new AuthError();
    const sessionUrl = await createCheckoutSession({
      userId: user.id, email: user.email!, priceId,
      successUrl: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/forge?upgraded=1`,
      cancelUrl: `${process.env.NEXT_PUBLIC_APP_URL}/pricing`,
    });
    return NextResponse.json({ url: sessionUrl });
  } catch (err) {
    return handleApiError(err);
  }
}
