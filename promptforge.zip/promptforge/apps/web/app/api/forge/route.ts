import { NextRequest } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { promptOptimizer } from '@promptforge/ai-engine';
import { cache, forgeRatelimit, RedisKeys } from '@promptforge/redis';
import { checkUsageLimit, incrementUsage, getMonthKey, getUserPlan, saveOptimization } from '@promptforge/db';
import { analyticsQueue, referralQueue } from '@promptforge/queue';
import { handleApiError, AuthError, UsageLimitError, PlanGateError, RateLimitError, ConflictError } from '@promptforge/errors';
import { isModelAllowed, PLAN_LIMITS } from '@promptforge/config';
import { logger } from '@promptforge/logger';
import type { TargetModel } from '@promptforge/config';

export const runtime = 'nodejs';
export const maxDuration = 60;

const ForgeSchema = z.object({
  prompt: z.string().min(10, 'Prompt too short').max(32_000, 'Prompt too long'),
  targetModel: z.enum([
    'gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo',
    'gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-2.0',
    'claude-3-5-sonnet', 'claude-3-opus', 'claude-3-haiku', 'general',
  ]),
});

export async function POST(req: NextRequest) {
  let userId: string | null = null;
  let lockAcquired = false;

  try {
    const body = ForgeSchema.parse(await req.json());

    // Auth
    const supabase = createClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) throw new AuthError();
    userId = user.id;

    // Per-user rate limit (20/min)
    const { success: rateOk } = await forgeRatelimit.limit(user.id);
    if (!rateOk) throw new RateLimitError(60);

    // Plan check
    const { plan } = await getUserPlan(user.id);
    if (!isModelAllowed(body.targetModel as TargetModel, plan)) {
      throw new PlanGateError('pro');
    }

    // Usage limit
    const { allowed, used, limit } = await checkUsageLimit(user.id, plan);
    if (!allowed) throw new UsageLimitError(used, limit);

    // Concurrency lock — একই user একসাথে দুটো request করতে পারবে না
    const lockKey = RedisKeys.forgeLock(user.id);
    lockAcquired = await cache.acquireLock(lockKey, 30);
    if (!lockAcquired) throw new ConflictError('Another optimization is already in progress');

    const encoder = new TextEncoder();
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();

    const send = async (data: unknown) => {
      await writer.write(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
    };

    // Process async, stream back
    (async () => {
      try {
        await send({ type: 'progress', step: 'analyzing', pct: 10 });

        const result = await promptOptimizer.optimize({
          prompt: body.prompt,
          targetModel: body.targetModel as TargetModel,
          userId: user.id,
          tier: plan,
        });

        await send({ type: 'progress', step: 'saving', pct: 80 });

        // BUG FIX: saved.id ব্যবহার করো, client-এ পাঠাও
        let savedId: string | null = null;
        if (!result.fromCache) {
          const saved = await saveOptimization({
            userId: user.id,
            originalPrompt: body.prompt,
            targetModel: body.targetModel,
            result,
          });
          savedId = saved?.id ?? null;
          await incrementUsage(user.id, getMonthKey());
        }

        // Background jobs
        void analyticsQueue.add('analytics', {
          event: 'optimization_complete',
          userId: user.id,
          properties: { model: body.targetModel, savingsPct: result.savingsPct, score: result.score, plan },
        }).catch(() => null);

        void referralQueue.add('referral', {
          userId: user.id,
          action: 'check_activation',
        }).catch(() => null);

        // Send result WITH optimizationId so client can create share link
        await send({ type: 'result', data: { ...result, optimizationId: savedId } });
        await send({ type: 'done' });

      } catch (err) {
        logger.error({ event: 'forge_stream_error', userId, err });
        await send({
          type: 'error',
          message: err instanceof Error ? err.message : 'Optimization failed',
          code: (err as { code?: string }).code,
        });
      } finally {
        if (lockAcquired) await cache.releaseLock(RedisKeys.forgeLock(userId!));
        await writer.close().catch(() => null);
      }
    })();

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',
      },
    });

  } catch (err) {
    if (lockAcquired && userId) {
      await cache.releaseLock(RedisKeys.forgeLock(userId)).catch(() => null);
    }
    return handleApiError(err);
  }
}
