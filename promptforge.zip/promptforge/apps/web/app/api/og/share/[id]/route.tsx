import { ImageResponse } from 'next/og';
import { getPublicOptimization } from '@promptforge/db';

export const runtime = 'edge';

export async function GET(req: Request, { params }: { params: { id: string } }) {
  const opt = await getPublicOptimization(params.id);
  if (!opt) return new Response('Not found', { status: 404 });

  const savings = Math.round(opt.savings_pct ?? 0);

  return new ImageResponse(
    (
      <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%', background: '#0a0a0f', padding: '60px', fontFamily: 'system-ui' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '32px' }}>
          <div style={{ fontSize: '28px', color: '#8b5cf6', fontWeight: 700 }}>⚡ PromptForge</div>
        </div>
        <div style={{ display: 'flex', gap: '48px', marginBottom: '32px' }}>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ fontSize: '72px', fontWeight: 900, color: '#22c55e', lineHeight: 1 }}>−{savings}%</div>
            <div style={{ fontSize: '20px', color: '#6b7280', marginTop: '8px' }}>token reduction</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ fontSize: '72px', fontWeight: 900, color: '#8b5cf6', lineHeight: 1 }}>{opt.quality_score}</div>
            <div style={{ fontSize: '20px', color: '#6b7280', marginTop: '8px' }}>quality score</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ fontSize: '32px', fontWeight: 700, color: '#fff', marginTop: '8px' }}>{opt.target_model}</div>
            <div style={{ fontSize: '20px', color: '#6b7280', marginTop: '8px' }}>target model</div>
          </div>
        </div>
        <div style={{ fontSize: '18px', color: '#374151', background: '#111827', padding: '20px 24px', borderRadius: '12px', maxHeight: '120px', overflow: 'hidden' }}>
          {opt.optimized_prompt.slice(0, 200)}{opt.optimized_prompt.length > 200 ? '…' : ''}
        </div>
      </div>
    ),
    { width: 1200, height: 630 },
  );
}
