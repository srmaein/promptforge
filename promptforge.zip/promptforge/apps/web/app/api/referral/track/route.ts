import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@promptforge/db';
import { cache, RedisKeys } from '@promptforge/redis';

const TrackSchema = z.object({ referralCode: z.string().length(12) });

export async function POST(req: NextRequest) {
  try {
    const { referralCode } = TrackSchema.parse(await req.json());
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0] ?? req.ip ?? 'unknown';

    const { data: referrer } = await db.from('users').select('id').eq('referral_code', referralCode).single();
    if (!referrer) return NextResponse.json({ valid: false });

    await cache.set(RedisKeys.pendingReferral(ip), referrer.id, 30 * 24 * 3600);
    return NextResponse.json({ valid: true });
  } catch {
    return NextResponse.json({ valid: false });
  }
}
