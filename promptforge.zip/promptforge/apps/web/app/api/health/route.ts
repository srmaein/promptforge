import { NextResponse } from 'next/server';
import { redis } from '@promptforge/redis';
import { db } from '@promptforge/db';

export const runtime = 'nodejs';

export async function GET() {
  const checks: Record<string, 'ok' | 'error'> = {};

  // Redis health
  try {
    await redis.ping();
    checks.redis = 'ok';
  } catch {
    checks.redis = 'error';
  }

  // DB health
  try {
    await db.from('users').select('count').limit(1);
    checks.database = 'ok';
  } catch {
    checks.database = 'error';
  }

  const healthy = Object.values(checks).every(v => v === 'ok');

  return NextResponse.json(
    { status: healthy ? 'healthy' : 'degraded', checks, ts: new Date().toISOString() },
    { status: healthy ? 200 : 503 },
  );
}
