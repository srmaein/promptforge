import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createShareLink, getUserPlan } from '@promptforge/db';
import { handleApiError, AuthError, PlanGateError } from '@promptforge/errors';

const ShareSchema = z.object({
  optimizationId: z.string().uuid('Invalid optimization ID'),
});

export async function POST(req: NextRequest) {
  try {
    const body = ShareSchema.parse(await req.json());

    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new AuthError();

    const { plan } = await getUserPlan(user.id);
    if (plan === 'free') throw new PlanGateError('pro');

    const updated = await createShareLink(body.optimizationId, user.id);
    if (!updated?.share_id) {
      return NextResponse.json({ error: 'Failed to create share link' }, { status: 500 });
    }

    const shareUrl = `${process.env.NEXT_PUBLIC_APP_URL}/share/${updated.share_id}`;
    return NextResponse.json({ shareId: updated.share_id, shareUrl });
  } catch (err) {
    return handleApiError(err);
  }
}
