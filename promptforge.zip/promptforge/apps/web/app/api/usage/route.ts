import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { getMonthlyUsage, getMonthKey, getUserPlan } from '@promptforge/db';
import { PLAN_LIMITS } from '@promptforge/config';
import { handleApiError, AuthError } from '@promptforge/errors';

export async function GET() {
  try {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new AuthError();

    const { plan } = await getUserPlan(user.id);
    const { used } = await getMonthlyUsage(user.id, getMonthKey());

    const planLimit = PLAN_LIMITS[plan].optimizationsPerMonth;
    const limit = planLimit === Infinity ? 999999 : planLimit;

    return NextResponse.json({
      used,
      limit,
      remaining: Math.max(0, limit - used),
      month: getMonthKey(),
      plan,
      resetAt: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString(),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
