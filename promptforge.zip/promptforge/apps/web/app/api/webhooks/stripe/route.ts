import { NextRequest } from 'next/server';
import { getStripe, syncSubscription, downgradeToFree } from '@promptforge/stripe';
import { db } from '@promptforge/db';
import { emailQueue } from '@promptforge/queue';
import { logger } from '@promptforge/logger';
import type Stripe from 'stripe';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature');
  if (!sig) return new Response('No signature', { status: 400 });

  const body = await req.text();
  const stripe = getStripe();

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    logger.warn({ event: 'stripe_webhook_invalid_sig', err });
    return new Response('Invalid signature', { status: 400 });
  }

  // Idempotency check
  const { data: existing } = await db
    .from('webhook_events')
    .select('id')
    .eq('id', event.id)
    .maybeSingle();

  if (existing) {
    logger.info({ event: 'webhook_duplicate', eventId: event.id });
    return new Response('Already processed', { status: 200 });
  }

  // Log event immediately
  await db.from('webhook_events').insert({
    id: event.id,
    type: event.type,
    payload: event.data.object as Record<string, unknown>,
  });

  try {
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        await syncSubscription(event.data.object as Stripe.Subscription);
        break;

      case 'customer.subscription.deleted':
        await downgradeToFree(event.data.object as Stripe.Subscription);
        const canceledSub = event.data.object as Stripe.Subscription;
        if (canceledSub.metadata?.userId) {
          await emailQueue.add('email', {
            type: 'subscription_canceled',
            userId: canceledSub.metadata.userId,
          });
        }
        break;

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        const customer = typeof invoice.customer === 'string' ? invoice.customer : invoice.customer?.id;
        if (customer) {
          const { data: user } = await db.from('users').select('id').eq('stripe_customer_id', customer).single();
          if (user) {
            await emailQueue.add('email', { type: 'payment_receipt', userId: user.id, metadata: { invoiceId: invoice.id } });
          }
        }
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        const customer = typeof invoice.customer === 'string' ? invoice.customer : invoice.customer?.id;
        if (customer) {
          const { data: user } = await db.from('users').select('id').eq('stripe_customer_id', customer).single();
          if (user) {
            await emailQueue.add('email', { type: 'payment_failed', userId: user.id });
          }
        }
        break;
      }
    }

    return new Response('OK', { status: 200 });
  } catch (err) {
    logger.error({ event: 'webhook_processing_error', eventId: event.id, type: event.type, err });
    return new Response('OK', { status: 200 }); // Don't let Stripe retry — we logged it
  }
}
