import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getPublicOptimization } from '@promptforge/db';

interface Props {
  params: { id: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const opt = await getPublicOptimization(params.id);
  if (!opt) return {};
  const savings = Math.round(opt.savings_pct ?? 0);
  return {
    title: `${savings}% token reduction for ${opt.target_model} | PromptForge`,
    description: `This AI prompt was optimized with PromptForge — ${savings}% fewer tokens with quality score ${opt.quality_score}/100.`,
    openGraph: {
      images: [{ url: `/api/og/share/${params.id}`, width: 1200, height: 630 }],
    },
  };
}

export default async function SharePage({ params }: Props) {
  const opt = await getPublicOptimization(params.id);
  if (!opt) notFound();

  const savings = Math.round(opt.savings_pct ?? 0);
  const savedTokens = (opt.original_tokens ?? 0) - (opt.optimized_tokens ?? 0);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <header className="border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-violet-600 font-bold text-lg">⚡ PromptForge</Link>
          <Link href="/signup" className="px-4 py-2 bg-violet-600 text-white text-sm font-medium rounded-lg hover:bg-violet-700 transition-colors">
            Optimize yours free →
          </Link>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-4 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 px-6 py-4 shadow-sm">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">−{savings}%</div>
              <div className="text-xs text-gray-500">tokens saved</div>
            </div>
            <div className="w-px h-10 bg-gray-200 dark:bg-gray-700"/>
            <div className="text-center">
              <div className="text-2xl font-bold text-violet-600">{opt.quality_score}</div>
              <div className="text-xs text-gray-500">quality score</div>
            </div>
            <div className="w-px h-10 bg-gray-200 dark:bg-gray-700"/>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900 dark:text-white">{savedTokens.toLocaleString()}</div>
              <div className="text-xs text-gray-500">tokens saved</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-500 uppercase tracking-wider">Original</span>
              <span className="text-xs px-2 py-1 rounded-full bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400">
                {opt.original_tokens?.toLocaleString()} tokens
              </span>
            </div>
            <pre className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap font-mono leading-relaxed">
              {opt.original_prompt}
            </pre>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl border-2 border-violet-200 dark:border-violet-800 p-6 relative">
            <div className="absolute -top-3 left-4 px-2 bg-violet-600 text-white text-xs font-semibold rounded-full">
              ⚡ Forged
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-gray-500 uppercase tracking-wider">Optimized</span>
              <span className="text-xs px-2 py-1 rounded-full bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400">
                {opt.optimized_tokens?.toLocaleString()} tokens
              </span>
            </div>
            <pre className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap font-mono leading-relaxed">
              {opt.optimized_prompt}
            </pre>
          </div>
        </div>

        <div className="mt-10 text-center">
          <p className="text-gray-600 dark:text-gray-400 mb-4">Optimize your own prompts for free</p>
          <Link href="/signup" className="inline-block px-8 py-4 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-colors text-lg shadow-lg shadow-violet-200 dark:shadow-violet-900/30">
            Start Forging Free →
          </Link>
        </div>
      </main>
    </div>
  );
}
