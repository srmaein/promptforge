import type { Metadata } from 'next';
import { getUser } from '@/lib/supabase/server';
import { getUserHistory } from '@promptforge/db';
import { HistoryList } from '@/components/forge/HistoryList';

export const metadata: Metadata = { title: 'History' };

export default async function HistoryPage({
  searchParams,
}: {
  searchParams: { page?: string };
}) {
  const user = await getUser();
  if (!user) return null;
  const page = Number(searchParams.page ?? 1);
  const { items, total } = await getUserHistory(user.id, 20, (page - 1) * 20);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Prompt History</h1>
        <p className="text-gray-500 mt-1 text-sm">{total.toLocaleString()} optimizations</p>
      </div>
      <HistoryList items={items} total={total} page={page} />
    </div>
  );
}
