import type { Metadata } from 'next';
import { getUser } from '@/lib/supabase/server';
import { db } from '@promptforge/db';
import { ReferralDashboard } from '@/components/billing/ReferralDashboard';

export const metadata: Metadata = { title: 'Referrals' };

export default async function ReferralPage() {
  const user = await getUser();
  if (!user) return null;

  const { data: userData } = await db.from('users').select('referral_code, referral_count').eq('id', user.id).single();
  const { data: events } = await db.from('referral_events').select('*').eq('referrer_id', user.id).order('triggered_at', { ascending: false }).limit(20);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Referrals</h1>
        <p className="text-gray-500 mt-1 text-sm">Invite friends and earn 50 free optimizations each.</p>
      </div>
      <ReferralDashboard
        referralCode={userData?.referral_code ?? ''}
        referralCount={userData?.referral_count ?? 0}
        events={events ?? []}
      />
    </div>
  );
}
