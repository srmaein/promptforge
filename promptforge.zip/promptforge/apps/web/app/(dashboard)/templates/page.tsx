import type { Metadata } from 'next';
import Link from 'next/link';
import { db } from '@promptforge/db';

export const metadata: Metadata = { title: 'Templates' };

const CATEGORIES = ['All', 'Coding', 'Writing', 'Analysis', 'Marketing', 'Education', 'Creative'];

export default async function TemplatesPage({
  searchParams,
}: {
  searchParams: { category?: string };
}) {
  const category = searchParams.category;
  let query = db.from('templates').select('*').eq('is_published', true).order('use_count', { ascending: false }).limit(24);
  if (category && category !== 'All') query = query.eq('category', category.toLowerCase());
  const { data: templates } = await query;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Template Marketplace</h1>
          <p className="text-gray-500 mt-1 text-sm">Community-published, AI-optimized prompt templates</p>
        </div>
        <Link href="/dashboard/templates/new"
          className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white text-sm font-medium rounded-lg transition-colors">
          + Publish Template
        </Link>
      </div>

      <div className="flex gap-2 flex-wrap">
        {CATEGORIES.map(cat => (
          <Link key={cat}
            href={cat === 'All' ? '/dashboard/templates' : `?category=${cat}`}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              (category ?? 'All') === cat
                ? 'bg-violet-600 text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}>
            {cat}
          </Link>
        ))}
      </div>

      {!templates?.length ? (
        <div className="text-center py-20 text-gray-400">
          <div className="text-4xl mb-4">📚</div>
          <p className="text-sm">No templates in this category yet. Be the first to publish!</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map(tmpl => (
            <div key={tmpl.id}
              className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5 hover:border-violet-300 dark:hover:border-violet-700 transition-colors group cursor-pointer">
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="font-semibold text-sm text-gray-900 dark:text-white group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">
                  {tmpl.title}
                </h3>
                {tmpl.is_featured && (
                  <span className="shrink-0 text-xs px-1.5 py-0.5 rounded bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400">
                    ⭐ Featured
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 mb-3">{tmpl.description}</p>
              <div className="flex items-center justify-between text-xs text-gray-400">
                <span className="capitalize bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded">{tmpl.category}</span>
                <span>{tmpl.use_count.toLocaleString()} uses</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
