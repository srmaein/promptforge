import type { Metadata } from 'next';
import { ForgeEditor } from '@/components/forge/ForgeEditor';
import { UsageBanner } from '@/components/forge/UsageBanner';
import { getUser } from '@/lib/supabase/server';
import { getUserPlan, getMonthlyUsage, getMonthKey } from '@promptforge/db';
import { PLAN_LIMITS } from '@promptforge/config';

export const metadata: Metadata = { title: 'Forge' };

export default async function ForgePage() {
  const user = await getUser();
  if (!user) return null;

  const { plan } = await getUserPlan(user.id);
  const { used } = await getMonthlyUsage(user.id, getMonthKey());

  const planLimit = PLAN_LIMITS[plan].optimizationsPerMonth;
  const limit = planLimit === Infinity ? 999999 : planLimit;
  const remaining = Math.max(0, limit - used);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Prompt Forge</h1>
        <p className="text-gray-500 mt-1 text-sm">
          Optimize your AI prompts for clarity, structure, and token efficiency.
        </p>
      </div>
      <UsageBanner used={used} limit={limit} remaining={remaining} plan={plan} />
      <ForgeEditor userId={user.id} plan={plan} remaining={remaining} />
    </div>
  );
}
