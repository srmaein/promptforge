import type { Metadata } from 'next';
import Link from 'next/link';
import { getUser } from '@/lib/supabase/server';
import { db, getUserPlan } from '@promptforge/db';
import { PLAN_LIMITS } from '@promptforge/config';

export const metadata: Metadata = { title: 'Settings' };

export default async function SettingsPage() {
  const user = await getUser();
  if (!user) return null;

  const [{ data: userData }, { plan }] = await Promise.all([
    db.from('users').select('full_name, referral_code, stripe_customer_id, subscription_status, created_at').eq('id', user.id).single(),
    getUserPlan(user.id),
  ]);

  const planConfig = PLAN_LIMITS[plan];

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <p className="text-gray-500 mt-1 text-sm">Manage your account and billing</p>
      </div>

      <section className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
        <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Account</h2>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-800">
            <span className="text-gray-500">Email</span>
            <span className="font-medium">{user.email}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-800">
            <span className="text-gray-500">Current plan</span>
            <span className="font-semibold capitalize text-violet-600 dark:text-violet-400">{plan}</span>
          </div>
          {userData?.subscription_status && (
            <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-800">
              <span className="text-gray-500">Subscription status</span>
              <span className={`font-medium capitalize ${userData.subscription_status === 'active' || userData.subscription_status === 'trialing' ? 'text-green-600' : 'text-yellow-600'}`}>
                {userData.subscription_status}
              </span>
            </div>
          )}
          <div className="flex justify-between py-2">
            <span className="text-gray-500">Member since</span>
            <span className="font-medium">{userData?.created_at ? new Date(userData.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : '—'}</span>
          </div>
        </div>
      </section>

      <section className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
        <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Billing</h2>
        {plan === 'free' ? (
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-sm text-gray-700 dark:text-gray-300 font-medium">You are on the Free plan</p>
              <p className="text-xs text-gray-500 mt-1">Upgrade to Pro for 500 optimizations/month and all 12 AI models.</p>
            </div>
            <Link href="/pricing"
              className="shrink-0 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white text-sm font-medium rounded-lg transition-colors">
              Upgrade to Pro
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-gray-700 dark:text-gray-300">
              You are on the <span className="font-semibold capitalize text-violet-600">{plan}</span> plan.
            </p>
            <form action="/api/billing/portal" method="POST">
              <button type="submit"
                className="text-sm text-violet-600 dark:text-violet-400 hover:underline font-medium">
                Manage subscription & invoices →
              </button>
            </form>
          </div>
        )}
      </section>

      <section className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
        <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Plan Features</h2>
        <div className="space-y-1 text-sm">
          {[
            ['Optimizations / month', planConfig.optimizationsPerMonth === Infinity ? 'Unlimited' : planConfig.optimizationsPerMonth.toLocaleString()],
            ['AI models', planConfig.allowedModels === 'ALL' ? 'All models' : `${(planConfig.allowedModels as string[]).length} models`],
            ['Prompt history', planConfig.historyDays === Infinity ? 'Unlimited' : `${planConfig.historyDays} days`],
            ['Max prompt size', `${(planConfig.maxPromptTokens / 1000).toFixed(0)}k tokens`],
            ['Share pages', planConfig.canShare ? '✓' : '✗'],
            ['Template publishing', planConfig.canPublishTemplates ? '✓' : '✗'],
            ['API access', planConfig.apiAccess ? '✓' : '✗'],
            ['Priority queue', planConfig.priorityQueue ? '✓' : '✗'],
          ].map(([label, value]) => (
            <div key={label as string} className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-800 last:border-0">
              <span className="text-gray-500">{label}</span>
              <span className={`font-medium ${value === '✓' ? 'text-green-600' : value === '✗' ? 'text-gray-300 dark:text-gray-600' : ''}`}>{value}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
        <h2 className="font-semibold text-gray-900 dark:text-white mb-4">Referral</h2>
        <p className="text-sm text-gray-500 mb-3">Share your referral link to earn 50 free optimizations per activation.</p>
        <Link href="/dashboard/referral"
          className="text-sm text-violet-600 dark:text-violet-400 hover:underline font-medium">
          View referral dashboard →
        </Link>
      </section>
    </div>
  );
}
