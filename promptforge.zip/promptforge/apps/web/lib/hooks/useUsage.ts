'use client';
import { useState, useEffect } from 'react';

interface UsageData {
  used: number;
  limit: number;
  remaining: number;
  plan: string;
}

export function useUsage() {
  const [usage, setUsage] = useState<UsageData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/usage')
      .then(r => r.json())
      .then(setUsage)
      .catch(() => null)
      .finally(() => setLoading(false));
  }, []);

  const refresh = () => {
    fetch('/api/usage').then(r => r.json()).then(setUsage).catch(() => null);
  };

  return { usage, loading, refresh };
}
