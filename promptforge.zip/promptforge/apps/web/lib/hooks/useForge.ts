'use client';
import { useState, useCallback } from 'react';
import type { OptimizationResult } from '@promptforge/types';
import type { TargetModel } from '@promptforge/config';

interface UseForgeState {
  result: OptimizationResult | null;
  loading: boolean;
  error: string;
  progress: number;
}

export function useForge() {
  const [state, setState] = useState<UseForgeState>({
    result: null,
    loading: false,
    error: '',
    progress: 0,
  });

  const forge = useCallback(async (prompt: string, targetModel: TargetModel) => {
    setState(s => ({ ...s, loading: true, error: '', result: null, progress: 0 }));

    try {
      const response = await fetch('/api/forge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, targetModel }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error ?? 'Request failed');
      }

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const lines = decoder.decode(value).split('\n').filter(l => l.startsWith('data: '));
        for (const line of lines) {
          const data = JSON.parse(line.slice(6));
          if (data.type === 'progress') setState(s => ({ ...s, progress: data.pct }));
          if (data.type === 'result') setState(s => ({ ...s, result: data.data, progress: 100 }));
          if (data.type === 'error') throw new Error(data.message);
        }
      }
    } catch (err) {
      setState(s => ({ ...s, error: err instanceof Error ? err.message : 'Something went wrong' }));
    } finally {
      setState(s => ({ ...s, loading: false }));
    }
  }, []);

  const reset = useCallback(() => {
    setState({ result: null, loading: false, error: '', progress: 0 });
  }, []);

  return { ...state, forge, reset };
}
