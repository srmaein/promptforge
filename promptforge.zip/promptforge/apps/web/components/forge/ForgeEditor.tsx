'use client';
import { useState } from 'react';
import { ModelSelector } from './ModelSelector';
import { ResultPanel } from './ResultPanel';
import type { TargetModel, PlanType } from '@promptforge/config';
import type { OptimizationResult } from '@promptforge/types';

type ForgeResult = OptimizationResult & { optimizationId?: string | null };

interface ForgeEditorProps {
  userId: string;
  plan: PlanType;
  remaining: number;
}

export function ForgeEditor({ userId, plan, remaining }: ForgeEditorProps) {
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState<TargetModel>('general');
  const [result, setResult] = useState<ForgeResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);

  const disabled = loading || remaining === 0 || prompt.trim().length < 10;

  async function handleForge() {
    if (disabled) return;
    setLoading(true);
    setError('');
    setResult(null);
    setProgress(0);

    try {
      const response = await fetch('/api/forge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: prompt.trim(), targetModel: model }),
      });

      if (!response.ok) {
        const err = await response.json().catch(() => ({ error: 'Request failed' }));
        throw new Error(err.error ?? 'Request failed');
      }

      if (!response.body) throw new Error('No response body');
      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const lines = decoder.decode(value, { stream: true })
          .split('\n')
          .filter(l => l.startsWith('data: '));

        for (const line of lines) {
          try {
            const data = JSON.parse(line.slice(6));
            if (data.type === 'progress') setProgress(data.pct);
            if (data.type === 'result') setResult(data.data as ForgeResult);
            if (data.type === 'error') throw new Error(data.message ?? 'Optimization failed');
          } catch (parseErr) {
            // Skip malformed SSE lines
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">
            Your prompt
          </label>
          <ModelSelector value={model} onChange={setModel} plan={plan} />
        </div>

        <textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder="Paste your AI prompt here. The messier the better — that's what we're for."
          rows={8}
          className="w-full resize-none rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 px-4 py-3 text-sm font-mono text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-violet-500 placeholder:text-gray-400 dark:placeholder:text-gray-600"
        />

        <div className="flex items-center justify-between mt-3">
          <span className="text-xs text-gray-400">{prompt.length.toLocaleString()} chars</span>
          <div className="flex items-center gap-3">
            {error && (
              <span className="text-xs text-red-500 max-w-xs truncate">{error}</span>
            )}
            <button
              onClick={handleForge}
              disabled={disabled}
              className="px-6 py-2.5 bg-violet-600 hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl transition-colors flex items-center gap-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                  </svg>
                  Forging… {progress > 0 ? `${progress}%` : ''}
                </>
              ) : (
                <>⚡ Forge Prompt</>
              )}
            </button>
          </div>
        </div>

        {remaining === 0 && (
          <p className="mt-2 text-xs text-red-500 text-center">
            Monthly limit reached.{' '}
            <a href="/pricing" className="underline font-medium">Upgrade to Pro →</a>
          </p>
        )}
      </div>

      {result && (
        <ResultPanel result={result} originalPrompt={prompt} plan={plan} />
      )}
    </div>
  );
}
