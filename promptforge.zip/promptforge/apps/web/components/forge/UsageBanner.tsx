import Link from 'next/link';
import type { PlanType } from '@promptforge/config';

interface UsageBannerProps {
  used: number;
  limit: number;
  remaining: number;
  plan: PlanType;
}

export function UsageBanner({ used, limit, remaining, plan }: UsageBannerProps) {
  if (plan !== 'free') return null;

  const pct = Math.min(100, (used / limit) * 100);
  const isNearLimit = pct >= 80;
  const isAtLimit = remaining === 0;

  return (
    <div className={`rounded-xl p-4 border ${isAtLimit ? 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800' : isNearLimit ? 'bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200 dark:border-yellow-800' : 'bg-gray-50 dark:bg-gray-900 border-gray-200 dark:border-gray-800'}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
          {isAtLimit ? '⚠️ Monthly limit reached' : `${used} / ${limit} optimizations used`}
        </span>
        <Link href="/dashboard/settings?tab=billing" className="text-xs font-semibold text-violet-600 hover:underline">
          Upgrade to Pro →
        </Link>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
        <div
          className={`h-1.5 rounded-full transition-all ${isAtLimit ? 'bg-red-500' : isNearLimit ? 'bg-yellow-500' : 'bg-violet-500'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
