'use client';
import { PLAN_LIMITS, isModelAllowed } from '@promptforge/config';
import type { TargetModel, PlanType } from '@promptforge/config';

const MODELS: { value: TargetModel; label: string; provider: string }[] = [
  { value: 'general', label: 'General (Auto)', provider: 'Any' },
  { value: 'gpt-4o', label: 'GPT-4o', provider: 'OpenAI' },
  { value: 'gpt-4o-mini', label: 'GPT-4o Mini', provider: 'OpenAI' },
  { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo', provider: 'OpenAI' },
  { value: 'gemini-1.5-pro', label: 'Gemini 1.5 Pro', provider: 'Google' },
  { value: 'gemini-1.5-flash', label: 'Gemini 1.5 Flash', provider: 'Google' },
  { value: 'gemini-2.0', label: 'Gemini 2.0', provider: 'Google' },
  { value: 'claude-3-5-sonnet', label: 'Claude 3.5 Sonnet', provider: 'Anthropic' },
  { value: 'claude-3-haiku', label: 'Claude 3 Haiku', provider: 'Anthropic' },
];

interface ModelSelectorProps {
  value: TargetModel;
  onChange: (model: TargetModel) => void;
  plan: PlanType;
}

export function ModelSelector({ value, onChange, plan }: ModelSelectorProps) {
  return (
    <div className="flex items-center gap-2">
      <label className="text-xs text-gray-500 dark:text-gray-400">Target:</label>
      <select
        value={value}
        onChange={e => onChange(e.target.value as TargetModel)}
        className="text-sm border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-violet-500"
      >
        {MODELS.map(m => {
          const allowed = isModelAllowed(m.value, plan);
          return (
            <option key={m.value} value={m.value} disabled={!allowed}>
              {m.label} ({m.provider}){!allowed ? ' — Pro' : ''}
            </option>
          );
        })}
      </select>
    </div>
  );
}
