'use client';
import Link from 'next/link';
import { formatRelativeDate } from '@/lib/utils/format';
import type { PromptOptimization } from '@promptforge/types';

interface HistoryListProps {
  items: PromptOptimization[];
  total: number;
  page: number;
}

export function HistoryList({ items, total, page }: HistoryListProps) {
  if (items.length === 0) {
    return (
      <div className="text-center py-20 text-gray-400">
        <div className="text-4xl mb-4">📋</div>
        <p className="text-sm">No optimizations yet. Go to <Link href="/dashboard/forge" className="text-violet-600 underline">Forge</Link> to start!</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {items.map(item => (
        <div key={item.id} className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5 hover:border-violet-300 dark:hover:border-violet-700 transition-colors">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-2 font-mono">
                {item.optimized_prompt}
              </p>
              <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                <span>{item.target_model}</span>
                <span>{formatRelativeDate(item.created_at)}</span>
              </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <div className="text-center">
                <div className="text-sm font-bold text-green-600">−{Math.round(item.savings_pct)}%</div>
                <div className="text-xs text-gray-400">tokens</div>
              </div>
              <div className="text-center">
                <div className="text-sm font-bold text-violet-600">{item.quality_score}</div>
                <div className="text-xs text-gray-400">score</div>
              </div>
              {item.share_id && (
                <Link href={`/share/${item.share_id}`} target="_blank"
                  className="text-xs px-2 py-1 rounded-full bg-violet-50 dark:bg-violet-900/20 text-violet-600 dark:text-violet-400 hover:underline">
                  🔗 Public
                </Link>
              )}
            </div>
          </div>
        </div>
      ))}

      {/* Pagination */}
      <div className="flex justify-center gap-2 pt-4">
        {page > 1 && (
          <Link href={`?page=${page - 1}`} className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            ← Previous
          </Link>
        )}
        {items.length === 20 && (
          <Link href={`?page=${page + 1}`} className="px-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
            Next →
          </Link>
        )}
      </div>
    </div>
  );
}
