'use client';
import { useState } from 'react';
import type { OptimizationResult } from '@promptforge/types';
import type { PlanType } from '@promptforge/config';

interface ResultPanelProps {
  result: OptimizationResult & { optimizationId?: string | null };
  originalPrompt: string;
  plan: PlanType;
}

export function ResultPanel({ result, originalPrompt, plan }: ResultPanelProps) {
  const [copied, setCopied] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [shareUrl, setShareUrl] = useState('');
  const [shareError, setShareError] = useState('');

  const savings = Math.round(result.savingsPct);
  const savedTokens = result.originalTokens - result.optimizedTokens;
  const scoreColor = result.score >= 80 ? 'text-green-600' : result.score >= 60 ? 'text-yellow-600' : 'text-red-500';

  async function handleCopy() {
    await navigator.clipboard.writeText(result.optimized);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  async function handleShare() {
    if (plan === 'free') {
      setShareError('Sharing requires Pro plan');
      return;
    }
    // BUG FIX: use real optimizationId
    if (!result.optimizationId) {
      setShareError('Cannot share a cached result. Try a new optimization.');
      return;
    }

    setSharing(true);
    setShareError('');
    try {
      const res = await fetch('/api/share', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ optimizationId: result.optimizationId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Failed');
      setShareUrl(data.shareUrl);
    } catch (err) {
      setShareError(err instanceof Error ? err.message : 'Share failed');
    } finally {
      setSharing(false);
    }
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border-2 border-violet-200 dark:border-violet-800 p-6 animate-fade-in">
      <div className="flex flex-wrap items-center gap-4 mb-5">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
            ⚡ Forged Result
            {result.fromCache && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400">cached</span>
            )}
          </h3>
        </div>
        <div className="flex items-center gap-5 text-sm">
          <div className="text-center">
            <div className={`text-xl font-bold ${scoreColor}`}>{result.score}</div>
            <div className="text-xs text-gray-400">score</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-green-600">−{savings}%</div>
            <div className="text-xs text-gray-400">tokens</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-gray-900 dark:text-white">{result.latencyMs}ms</div>
            <div className="text-xs text-gray-400">latency</div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 mb-4 text-sm">
        <span className="line-through text-gray-400">{result.originalTokens.toLocaleString()} tokens</span>
        <span className="text-gray-400">→</span>
        <span className="font-semibold">{result.optimizedTokens.toLocaleString()} tokens</span>
        <span className="px-2 py-0.5 rounded-full bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 text-xs font-semibold">
          −{savedTokens.toLocaleString()} tokens
        </span>
      </div>

      <pre className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 text-sm font-mono text-gray-800 dark:text-gray-200 whitespace-pre-wrap leading-relaxed mb-4 overflow-auto max-h-80">
        {result.optimized}
      </pre>

      <div className="flex flex-wrap items-center gap-3">
        <button onClick={handleCopy}
          className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg text-sm font-medium transition-colors">
          {copied ? '✓ Copied!' : '📋 Copy'}
        </button>

        {!shareUrl && (
          <button onClick={handleShare} disabled={sharing || plan === 'free'}
            title={plan === 'free' ? 'Upgrade to Pro to share' : ''}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors">
            {sharing ? 'Sharing…' : '🔗 Share'}
          </button>
        )}

        {shareUrl && (
          <a href={shareUrl} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 rounded-lg text-sm font-medium hover:underline">
            ✓ View public link
          </a>
        )}

        {shareError && <span className="text-xs text-red-500">{shareError}</span>}
        <span className="ml-auto text-xs text-gray-400">{result.provider} / {result.model}</span>
      </div>
    </div>
  );
}
