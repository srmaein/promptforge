'use client';
import { useState } from 'react';

interface ReferralDashboardProps {
  referralCode: string;
  referralCount: number;
  events: Array<{ id: string; reward_granted: boolean; reward_value: number | null; triggered_at: string }>;
}

export function ReferralDashboard({ referralCode, referralCount, events }: ReferralDashboardProps) {
  const [copied, setCopied] = useState(false);
  const referralUrl = `${typeof window !== 'undefined' ? window.location.origin : ''}/signup?ref=${referralCode}`;

  async function handleCopy() {
    await navigator.clipboard.writeText(referralUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-900/20 dark:to-purple-900/20 rounded-2xl border border-violet-200 dark:border-violet-800 p-6">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-1">Your referral link</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Share this link. When someone activates their 3rd optimization, you both get +50 free optimizations.</p>
        <div className="flex items-center gap-3">
          <input readOnly value={referralUrl}
            className="flex-1 px-4 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm font-mono focus:outline-none"/>
          <button onClick={handleCopy}
            className="px-4 py-2.5 bg-violet-600 hover:bg-violet-700 text-white text-sm font-medium rounded-xl transition-colors">
            {copied ? '✓ Copied' : 'Copy'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 text-center">
          <div className="text-2xl font-bold text-violet-600">{referralCount}</div>
          <div className="text-xs text-gray-500 mt-1">Total referrals</div>
        </div>
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{events.filter(e => e.reward_granted).length}</div>
          <div className="text-xs text-gray-500 mt-1">Rewards earned</div>
        </div>
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 text-center">
          <div className="text-2xl font-bold text-gray-900 dark:text-white">
            {events.reduce((sum, e) => sum + (e.reward_value ?? 0), 0)}
          </div>
          <div className="text-xs text-gray-500 mt-1">Credits earned</div>
        </div>
      </div>

      {events.length > 0 && (
        <div>
          <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300 mb-3">Recent referral events</h4>
          <div className="space-y-2">
            {events.map(event => (
              <div key={event.id} className="flex items-center justify-between py-3 border-b border-gray-100 dark:border-gray-800 last:border-0">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${event.reward_granted ? 'bg-green-500' : 'bg-gray-300'}`}/>
                  <span className="text-sm text-gray-700 dark:text-gray-300">
                    {event.reward_granted ? `+${event.reward_value} credits earned` : 'Pending activation'}
                  </span>
                </div>
                <span className="text-xs text-gray-400">
                  {new Date(event.triggered_at).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
