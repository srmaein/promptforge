import Link from 'next/link';

const LINKS = {
  Product: [
    { label: 'Features', href: '/#features' },
    { label: 'Pricing', href: '/pricing' },
    { label: 'Templates', href: '/templates' },
    { label: 'Chrome Extension', href: '/extension' },
  ],
  Developers: [
    { label: 'API Docs', href: '/docs/api' },
    { label: 'VS Code Extension', href: '/vscode' },
    { label: 'GitHub', href: 'https://github.com/promptforge' },
    { label: 'Status', href: 'https://status.promptforge.ai' },
  ],
  Company: [
    { label: 'Blog', href: '/blog' },
    { label: 'Privacy', href: '/privacy' },
    { label: 'Terms', href: '/terms' },
    { label: 'Contact', href: 'mailto:hello@promptforge.ai' },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid sm:grid-cols-4 gap-8">
          <div>
            <div className="text-xl font-bold text-violet-600 mb-3">⚡ PromptForge</div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Transform messy prompts into structured, token-efficient AI prompts.</p>
          </div>
          {Object.entries(LINKS).map(([section, links]) => (
            <div key={section}>
              <h4 className="font-semibold text-sm text-gray-900 dark:text-white mb-3">{section}</h4>
              <ul className="space-y-2">
                {links.map(link => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 pt-6 border-t border-gray-200 dark:border-gray-800 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} PromptForge. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
