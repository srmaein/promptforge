#!/usr/bin/env bash
# PromptForge — First-time setup script
set -e

echo "🚀 Setting up PromptForge..."

# Check prerequisites
command -v node >/dev/null 2>&1 || { echo "❌ Node.js 20+ required"; exit 1; }
command -v pnpm >/dev/null 2>&1 || { npm install -g pnpm@9; }

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
  echo "❌ Node.js 20+ required (found v$NODE_VERSION)"; exit 1;
fi

echo "✓ Node.js $(node -v)"
echo "✓ pnpm $(pnpm -v)"

# Install dependencies
echo "📦 Installing dependencies..."
pnpm install

# Copy .env
if [ ! -f .env.local ]; then
  cp .env.example .env.local
  echo "✓ Created .env.local — add your API keys"
else
  echo "✓ .env.local already exists"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Fill in .env.local with your API keys"
echo "  2. Run migrations: open Supabase SQL editor → paste packages/db/migrations/001_initial_schema.sql"
echo "  3. Start dev: pnpm dev"
echo ""
