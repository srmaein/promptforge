#!/usr/bin/env bash
# Run all pending migrations against Supabase
set -e
echo "Running migrations..."
for f in packages/db/migrations/*.sql; do
  echo "→ $f"
  cat "$f" | npx supabase db push --db-url "$DATABASE_URL"
done
echo "✅ Migrations complete"
