# ⚡ PromptForge

**AI-powered prompt optimization platform.** Transform messy, bloated prompts into structured, token-efficient prompts for GPT-4, Claude, Gemini, and 12+ other models.

## Architecture

```
promptforge/
├── apps/
│   ├── web/                 # Next.js 14 App Router (Vercel)
│   ├── workers/             # BullMQ job processors (Fly.io)
│   ├── chrome-ext/          # Chrome Extension (MV3)
│   └── vscode-ext/          # VS Code Extension
├── packages/
│   ├── ai-engine/           # Core optimization engine
│   ├── config/              # Env validation + plan limits
│   ├── db/                  # Supabase client + queries
│   ├── errors/              # Typed error classes
│   ├── logger/              # Pino structured logging
│   ├── queue/               # BullMQ queue definitions
│   ├── redis/               # Upstash Redis client + cache
│   ├── stripe/              # Stripe subscription management
│   ├── token-counter/       # tiktoken + approximation
│   ├── types/               # Shared TypeScript types
│   └── ui/                  # Shared React components
├── infrastructure/
│   ├── fly/fly.toml         # Worker deployment config
│   └── terraform/main.tf    # Infrastructure as code
└── .github/workflows/ci.yml # Full CI/CD pipeline
```

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, TypeScript, Tailwind CSS |
| Database | Supabase (PostgreSQL + pgvector) |
| Auth | Supabase Auth |
| Cache | Upstash Redis |
| Queue | BullMQ + ioredis |
| AI Providers | Gemini 1.5, GPT-4o, Claude 3.5 |
| Payments | Stripe |
| Email | Resend |
| Monitoring | Pino, PostHog, Sentry |
| Web Deploy | Vercel |
| Worker Deploy | Fly.io |
| Monorepo | Turborepo + pnpm |

## Quick Start

```bash
# 1. Install dependencies
pnpm install

# 2. Configure environment
cp .env.example .env.local
# Fill in all required values

# 3. Run database migrations
# Open Supabase SQL editor and run:
# packages/db/migrations/001_initial_schema.sql
# packages/db/migrations/002_search_function.sql

# 4. Start development
pnpm dev
```

## Key Features

- **40% token reduction** on average via AI-powered RCTF structuring
- **Model-specific optimization** for GPT-4o, Claude, Gemini, etc.
- **Quality scoring** (0–100) on every output
- **SSE streaming** for real-time results
- **Viral share pages** — every optimization is a shareable URL
- **Referral system** — 50 credits each on 3rd activation
- **Chrome Extension** — ⚡ Forge button in ChatGPT, Claude, Gemini
- **VS Code Extension** — Ctrl+Shift+P to optimize in-editor
- **Template marketplace** with semantic search (pgvector)
- **BullMQ workers** — async jobs on separate Fly.io process

## Plans

| | Free | Pro ($12/mo) | Team ($49/mo) |
|--|------|-------------|--------------|
| Optimizations | 25/mo | 500/mo | Unlimited |
| Models | 3 | All 12 | All + Early Access |
| Share pages | ✗ | ✓ | ✓ |
| API access | ✗ | ✗ | ✓ |
| History | 7 days | Unlimited | Unlimited |

## Scaling Economics

```
At 10,000 MAU (5% Pro conversion = 500 users):
  Revenue:    500 × $12 = $6,000/mo
  AI costs:   ~$5–10/mo (40% cache hit rate)
  Infra:      ~$60/mo (Vercel + Fly.io + Redis)
  Gross margin: ~98%
```

## Deployment

```bash
# Web (Vercel)
vercel deploy --prod

# Workers (Fly.io)
flyctl deploy --app promptforge-workers

# Chrome Extension
pnpm --filter @promptforge/chrome-ext build
# Upload dist/ to Chrome Web Store

# VS Code Extension
pnpm --filter promptforge-vscode compile
# Package with vsce
```

## Environment Variables

See `.env.example` for all required variables. Key ones:

- `GEMINI_API_KEY` — Primary AI provider
- `OPENAI_API_KEY` — Fallback + embeddings
- `NEXT_PUBLIC_SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY`
- `UPSTASH_REDIS_REST_URL` + token
- `STRIPE_SECRET_KEY` + webhook secret + price IDs
- `RESEND_API_KEY` — Transactional email

---

Built with TypeScript, Next.js 14, Supabase, Upstash Redis, BullMQ, Stripe, and Turborepo.
