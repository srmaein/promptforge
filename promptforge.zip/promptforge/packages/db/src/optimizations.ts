import { db } from './client';
import { nanoid } from 'nanoid';
import type { OptimizationResult } from '@promptforge/types';

export async function saveOptimization(params: {
  userId: string;
  originalPrompt: string;
  targetModel: string;
  result: OptimizationResult;
}) {
  const { data, error } = await db
    .from('prompt_optimizations')
    .insert({
      user_id: params.userId,
      original_prompt: params.originalPrompt,
      optimized_prompt: params.result.optimized,
      original_tokens: params.result.originalTokens,
      optimized_tokens: params.result.optimizedTokens,
      target_model: params.targetModel,
      quality_score: params.result.score,
      structure_type: params.result.structure.type,
      metadata: {
        provider: params.result.provider,
        model: params.result.model,
        latencyMs: params.result.latencyMs,
        fromCache: params.result.fromCache,
      },
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function createShareLink(optimizationId: string, userId: string) {
  const shareId = nanoid(12);

  const { data, error } = await db
    .from('prompt_optimizations')
    .update({ share_id: shareId, is_public: true })
    .eq('id', optimizationId)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function getPublicOptimization(shareId: string) {
  const { data } = await db
    .from('prompt_optimizations')
    .select('*')
    .eq('share_id', shareId)
    .eq('is_public', true)
    .single();
  return data;
}

export async function getUserHistory(
  userId: string,
  limit = 20,
  offset = 0,
) {
  const { data, count } = await db
    .from('prompt_optimizations')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  return { items: data ?? [], total: count ?? 0 };
}
