// Auto-generated types from Supabase schema
// Run: npx supabase gen types typescript --local > src/database.types.ts

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          plan: 'free' | 'pro' | 'team' | 'enterprise';
          subscription_status: 'active' | 'trialing' | 'past_due' | 'canceled' | 'paused' | null;
          stripe_customer_id: string | null;
          stripe_subscription_id: string | null;
          referral_code: string;
          referred_by: string | null;
          referral_count: number;
          onboarded_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['users']['Row'], 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['users']['Insert']>;
      };
      prompt_optimizations: {
        Row: {
          id: string;
          user_id: string;
          original_prompt: string;
          optimized_prompt: string;
          original_tokens: number;
          optimized_tokens: number;
          savings_pct: number;
          target_model: string;
          quality_score: number;
          structure_type: string | null;
          share_id: string | null;
          is_public: boolean;
          is_starred: boolean;
          title: string | null;
          tags: string[];
          metadata: Json;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['prompt_optimizations']['Row'], 'id' | 'created_at' | 'savings_pct'>;
        Update: Partial<Database['public']['Tables']['prompt_optimizations']['Insert']>;
      };
      usage_records: {
        Row: {
          id: string;
          user_id: string;
          month_key: string;
          optimizations_used: number;
          optimizations_limit: number;
          tokens_processed: number;
          api_calls: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['usage_records']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['usage_records']['Insert']>;
      };
      templates: {
        Row: {
          id: string;
          author_id: string;
          title: string;
          description: string;
          template_body: string;
          variables: Json;
          category: string;
          target_models: string[];
          tags: string[];
          is_published: boolean;
          is_featured: boolean;
          use_count: number;
          like_count: number;
          slug: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['templates']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['templates']['Insert']>;
      };
      referral_events: {
        Row: {
          id: string;
          referrer_id: string;
          referred_id: string;
          reward_granted: boolean;
          reward_type: string | null;
          reward_value: number | null;
          triggered_at: string;
        };
        Insert: Omit<Database['public']['Tables']['referral_events']['Row'], 'id' | 'triggered_at'>;
        Update: Partial<Database['public']['Tables']['referral_events']['Insert']>;
      };
      webhook_events: {
        Row: {
          id: string;
          type: string;
          processed_at: string;
          payload: Json;
        };
        Insert: Database['public']['Tables']['webhook_events']['Row'];
        Update: Partial<Database['public']['Tables']['webhook_events']['Row']>;
      };
    };
  };
};
