import { db } from './client';
import { cache, RedisKeys } from '@promptforge/redis';
import { PLAN_LIMITS } from '@promptforge/config';
import type { PlanType } from '@promptforge/config';
import { logger } from '@promptforge/logger';

export function getMonthKey(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

// BUG FIX: return only used count, let callers compute limit from plan
export async function getMonthlyUsage(
  userId: string,
  monthKey: string,
): Promise<{ used: number }> {
  const cacheKey = RedisKeys.usageCache(userId, monthKey);
  const cached = await cache.get<number>(cacheKey);

  if (cached !== null) {
    return { used: cached };
  }

  const { data } = await db
    .from('usage_records')
    .select('optimizations_used')
    .eq('user_id', userId)
    .eq('month_key', monthKey)
    .maybeSingle();

  const used = data?.optimizations_used ?? 0;
  await cache.set(cacheKey, used, 300); // cache 5 min
  return { used };
}

export async function incrementUsage(userId: string, monthKey: string): Promise<void> {
  const { error } = await db.rpc('increment_usage', {
    p_user_id: userId,
    p_month_key: monthKey,
  });

  if (error) {
    logger.error({ event: 'usage_increment_failed', userId, monthKey, error });
    throw new Error('Failed to update usage');
  }

  await cache.del(RedisKeys.usageCache(userId, monthKey));
}

export async function getUserPlan(userId: string): Promise<{ plan: PlanType }> {
  const cacheKey = RedisKeys.userPlanCache(userId);
  const cached = await cache.get<{ plan: PlanType }>(cacheKey);
  if (cached) return cached;

  const { data, error } = await db
    .from('users')
    .select('plan')
    .eq('id', userId)
    .single();

  if (error || !data) throw new Error(`User ${userId} not found`);

  const result = { plan: data.plan as PlanType };
  await cache.set(cacheKey, result, 300);
  return result;
}

export async function checkUsageLimit(
  userId: string,
  plan: PlanType,
): Promise<{ allowed: boolean; used: number; limit: number }> {
  const monthKey = getMonthKey();
  const planLimit = PLAN_LIMITS[plan].optimizationsPerMonth;

  if (planLimit === Infinity) {
    return { allowed: true, used: 0, limit: 999999 };
  }

  const { used } = await getMonthlyUsage(userId, monthKey);
  return { allowed: used < planLimit, used, limit: planLimit };
}
