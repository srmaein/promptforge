import { db } from './client';
import { logger } from '@promptforge/logger';
import { getMonthKey } from './usage';

export async function checkReferralActivation(userId: string): Promise<void> {
  const monthKey = getMonthKey();

  const { data: usageData } = await db
    .from('usage_records')
    .select('optimizations_used')
    .eq('user_id', userId)
    .eq('month_key', monthKey)
    .maybeSingle();

  // Activate on exactly 3rd optimization
  if (!usageData || usageData.optimizations_used !== 3) return;

  const { data: user } = await db
    .from('users')
    .select('referred_by')
    .eq('id', userId)
    .single();

  if (!user?.referred_by) return;

  // Already rewarded?
  const { data: existing } = await db
    .from('referral_events')
    .select('id')
    .eq('referred_id', userId)
    .eq('reward_granted', true)
    .maybeSingle();

  if (existing) return;

  // Grant reward — log event (email is sent by the referral worker processor)
  await db.from('referral_events').insert({
    referrer_id: user.referred_by,
    referred_id: userId,
    reward_granted: true,
    reward_type: 'optimization_credits',
    reward_value: 50,
  });

  await db.rpc('increment_referral_count', { p_user_id: user.referred_by });

  logger.info({ event: 'referral_activated', referrerId: user.referred_by, referredId: userId });
}
