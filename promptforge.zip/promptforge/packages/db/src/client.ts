import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

let _adminClient: ReturnType<typeof createClient<Database>> | null = null;

// Server-side admin client (service role — bypasses RLS)
export function getAdminClient() {
  if (!_adminClient) {
    _adminClient = createClient<Database>(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      },
    );
  }
  return _adminClient;
}

// Convenience alias
export const db = new Proxy(
  {} as ReturnType<typeof createClient<Database>>,
  {
    get(_target, prop) {
      return getAdminClient()[prop as keyof ReturnType<typeof createClient<Database>>];
    },
  },
);
