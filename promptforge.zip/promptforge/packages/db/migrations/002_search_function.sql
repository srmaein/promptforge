-- Hybrid semantic + keyword template search
CREATE OR REPLACE FUNCTION search_templates(
  query_embedding VECTOR(1536),
  query_text TEXT,
  filter_category TEXT DEFAULT NULL,
  filter_model TEXT DEFAULT NULL,
  page_offset INT DEFAULT 0,
  page_limit INT DEFAULT 20
)
RETURNS TABLE (
  id UUID, title TEXT, description TEXT, author_id UUID,
  category TEXT, use_count INT, like_count INT, slug TEXT,
  tags TEXT[], target_models TEXT[], similarity FLOAT
)
LANGUAGE SQL STABLE AS $$
  SELECT
    id, title, description, author_id, category,
    use_count, like_count, slug, tags, target_models,
    (1 - (embedding <=> query_embedding)) AS similarity
  FROM templates
  WHERE
    is_published = true
    AND (filter_category IS NULL OR category = filter_category)
    AND (filter_model IS NULL OR filter_model = ANY(target_models))
    AND (
      to_tsvector('english', title || ' ' || description) @@ plainto_tsquery('english', query_text)
      OR (embedding IS NOT NULL AND (1 - (embedding <=> query_embedding)) > 0.70)
    )
  ORDER BY
    ((1 - (embedding <=> query_embedding)) * 0.6 + LOG(use_count + 1) * 0.4) DESC
  LIMIT page_limit OFFSET page_offset;
$$;
