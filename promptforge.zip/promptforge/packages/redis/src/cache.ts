import { getRedisClient } from './client';
import { logger } from '@promptforge/logger';

export class RedisCache {
  private client = getRedisClient();

  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await this.client.get<T>(key);
      return value;
    } catch (err) {
      logger.warn({ event: 'redis_get_error', key, err });
      return null;
    }
  }

  async set<T>(key: string, value: T, ttlSeconds?: number): Promise<void> {
    try {
      if (ttlSeconds) {
        await this.client.setex(key, ttlSeconds, JSON.stringify(value));
      } else {
        await this.client.set(key, JSON.stringify(value));
      }
    } catch (err) {
      logger.warn({ event: 'redis_set_error', key, err });
    }
  }

  async del(key: string): Promise<void> {
    try {
      await this.client.del(key);
    } catch (err) {
      logger.warn({ event: 'redis_del_error', key, err });
    }
  }

  async incr(key: string, ttlSeconds?: number): Promise<number> {
    const value = await this.client.incr(key);
    if (ttlSeconds && value === 1) {
      await this.client.expire(key, ttlSeconds);
    }
    return value;
  }

  async exists(key: string): Promise<boolean> {
    const result = await this.client.exists(key);
    return result === 1;
  }

  // Atomic lock: returns true if lock acquired
  async acquireLock(key: string, ttlSeconds = 30): Promise<boolean> {
    const result = await this.client.set(key, '1', {
      nx: true,
      ex: ttlSeconds,
    });
    return result === 'OK';
  }

  async releaseLock(key: string): Promise<void> {
    await this.client.del(key);
  }
}

export const cache = new RedisCache();
