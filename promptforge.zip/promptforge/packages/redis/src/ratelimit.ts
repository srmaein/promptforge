import { Ratelimit } from '@upstash/ratelimit';
import { getRedisClient } from './client';

// Lazy init — module load-এ Redis connect করবে না
let _forge: Ratelimit | null = null;
let _api: Ratelimit | null = null;
let _global: Ratelimit | null = null;
let _auth: Ratelimit | null = null;

export const forgeRatelimit = {
  limit: (id: string) => {
    if (!_forge) _forge = new Ratelimit({ redis: getRedisClient(), limiter: Ratelimit.slidingWindow(20, '1 m'), analytics: true, prefix: 'rate:forge' });
    return _forge.limit(id);
  },
};

export const apiRatelimit = {
  limit: (id: string) => {
    if (!_api) _api = new Ratelimit({ redis: getRedisClient(), limiter: Ratelimit.slidingWindow(60, '1 m'), analytics: true, prefix: 'rate:api' });
    return _api.limit(id);
  },
};

export const globalRatelimit = {
  limit: (id: string) => {
    if (!_global) _global = new Ratelimit({ redis: getRedisClient(), limiter: Ratelimit.slidingWindow(200, '1 m'), analytics: true, prefix: 'rate:global' });
    return _global.limit(id);
  },
};

export const authRatelimit = {
  limit: (id: string) => {
    if (!_auth) _auth = new Ratelimit({ redis: getRedisClient(), limiter: Ratelimit.slidingWindow(10, '15 m'), analytics: true, prefix: 'rate:auth' });
    return _auth.limit(id);
  },
};
