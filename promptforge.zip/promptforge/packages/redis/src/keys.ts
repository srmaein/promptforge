// Centralized Redis key definitions — prevents key collisions across the codebase
export const RedisKeys = {
  // Caching
  optimizationCache: (hash: string) => `cache:opt:${hash}`,
  templateCache: (id: string) => `cache:tmpl:${id}`,
  userPlanCache: (userId: string) => `cache:plan:${userId}`,
  usageCache: (userId: string, month: string) => `cache:usage:${userId}:${month}`,

  // Locks
  forgeLock: (userId: string) => `lock:forge:${userId}`,
  dedupLock: (userId: string, hash: string) => `dedup:${userId}:${hash}`,

  // Rate limiting (managed by Ratelimit instances, but documented here)
  forgeRate: (identifier: string) => `rate:forge:${identifier}`,
  apiRate: (identifier: string) => `rate:api:${identifier}`,

  // Sessions
  session: (token: string) => `session:${token}`,

  // Referral
  pendingReferral: (ip: string) => `referral:pending:${ip}`,

  // Budget tracking
  aiDailySpend: () => 'ai:daily_spend',
  aiMonthlySpend: () => 'ai:monthly_spend',
} as const;
