import Anthropic from '@anthropic-ai/sdk';
import type { AIProvider, CompletionResult } from './base';
import { logger } from '@promptforge/logger';

export class AnthropicProvider implements AIProvider {
  name = 'anthropic' as const;
  private client: Anthropic;

  constructor() {
    this.client = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
      maxRetries: 2,
      timeout: 30_000,
    });
  }

  isAvailable(): boolean {
    return !!process.env.ANTHROPIC_API_KEY;
  }

  async complete(
    systemPrompt: string,
    userPrompt: string,
    model = 'claude-3-haiku-20240307',
  ): Promise<CompletionResult> {
    const response = await this.client.messages.create({
      model,
      max_tokens: 4096,
      temperature: 0.3,
      system: systemPrompt,
      messages: [{ role: 'user', content: userPrompt }],
    });

    const block = response.content[0];
    const text = block?.type === 'text' ? block.text : '';
    if (!text) throw new Error('Anthropic returned empty response');

    logger.debug({
      event: 'anthropic_completion',
      model,
      inputTokens: response.usage?.input_tokens,
      outputTokens: response.usage?.output_tokens,
    });

    return {
      text,
      model,
      inputTokens: response.usage?.input_tokens ?? 0,
      outputTokens: response.usage?.output_tokens ?? 0,
    };
  }
}
