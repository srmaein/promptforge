import { GoogleGenerativeAI } from '@google/generative-ai';
import type { AIProvider, CompletionResult } from './base';
import { logger } from '@promptforge/logger';

export class GeminiProvider implements AIProvider {
  name = 'gemini' as const;
  private client: GoogleGenerativeAI;

  constructor() {
    this.client = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
  }

  isAvailable(): boolean {
    return !!process.env.GEMINI_API_KEY;
  }

  async complete(
    systemPrompt: string,
    userPrompt: string,
    model = 'gemini-1.5-flash',
  ): Promise<CompletionResult> {
    const genModel = this.client.getGenerativeModel({
      model,
      systemInstruction: systemPrompt,
      generationConfig: {
        temperature: 0.3,
        topP: 0.95,
        maxOutputTokens: 4096,
      },
    });

    const result = await genModel.generateContent(userPrompt);
    const text = result.response.text();

    if (!text) throw new Error('Gemini returned empty response');

    logger.debug({
      event: 'gemini_completion',
      model,
      inputTokens: result.response.usageMetadata?.promptTokenCount,
      outputTokens: result.response.usageMetadata?.candidatesTokenCount,
    });

    return {
      text,
      model,
      inputTokens: result.response.usageMetadata?.promptTokenCount ?? 0,
      outputTokens: result.response.usageMetadata?.candidatesTokenCount ?? 0,
    };
  }
}
