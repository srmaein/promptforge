import type { AIProvider, CompletionResult } from './base';
import { GeminiProvider } from './gemini';
import { OpenAIProvider } from './openai';
import { AnthropicProvider } from './anthropic';
import type { TargetModel } from '@promptforge/config';
import { logger } from '@promptforge/logger';

const MODEL_TO_PROVIDER: Partial<Record<TargetModel, string>> = {
  'gemini-1.5-pro':    'gemini',
  'gemini-1.5-flash':  'gemini',
  'gemini-2.0':        'gemini',
  'gpt-4o':            'openai',
  'gpt-4o-mini':       'openai',
  'gpt-4-turbo':       'openai',
  'gpt-3.5-turbo':     'openai',
  'claude-3-5-sonnet': 'anthropic',
  'claude-3-opus':     'anthropic',
  'claude-3-haiku':    'anthropic',
  'general':           'gemini',
};

const FALLBACK_ORDER = ['gemini', 'openai', 'anthropic'];

export class AIProviderRegistry {
  private providers: Map<string, AIProvider> = new Map();

  constructor() {
    this.register(new GeminiProvider());
    this.register(new OpenAIProvider());
    this.register(new AnthropicProvider());
  }

  private register(provider: AIProvider) {
    if (provider.isAvailable()) {
      this.providers.set(provider.name, provider);
      logger.debug({ event: 'provider_registered', name: provider.name });
    }
  }

  selectFor(targetModel: TargetModel): AIProvider {
    const providerName = MODEL_TO_PROVIDER[targetModel] ?? 'gemini';
    const provider = this.providers.get(providerName);
    if (provider) return provider;

    // Fallback if primary provider not configured
    for (const name of FALLBACK_ORDER) {
      const fallback = this.providers.get(name);
      if (fallback) return fallback;
    }

    throw new Error('No AI providers available. Check API key configuration.');
  }

  async completeWithFallback(
    systemPrompt: string,
    userPrompt: string,
    targetModel: TargetModel,
  ): Promise<CompletionResult & { provider: string }> {
    const primary = this.selectFor(targetModel);
    const primaryModel = this.getModelString(targetModel, primary.name);

    try {
      const result = await primary.complete(systemPrompt, userPrompt, primaryModel);
      return { ...result, provider: primary.name };
    } catch (err) {
      logger.warn({ event: 'provider_fallback', from: primary.name, err });

      const fallbacks = FALLBACK_ORDER
        .filter(n => n !== primary.name)
        .map(n => this.providers.get(n))
        .filter(Boolean) as AIProvider[];

      for (const fallback of fallbacks) {
        try {
          const result = await fallback.complete(systemPrompt, userPrompt);
          logger.info({ event: 'fallback_success', provider: fallback.name });
          return { ...result, provider: fallback.name };
        } catch {}
      }

      throw new Error('All AI providers failed');
    }
  }

  private getModelString(target: TargetModel, providerName: string): string {
    const modelMap: Partial<Record<TargetModel, string>> = {
      'gpt-4o':            'gpt-4o',
      'gpt-4o-mini':       'gpt-4o-mini',
      'gpt-4-turbo':       'gpt-4-turbo-preview',
      'gpt-3.5-turbo':     'gpt-3.5-turbo',
      'gemini-1.5-pro':    'gemini-1.5-pro',
      'gemini-1.5-flash':  'gemini-1.5-flash',
      'gemini-2.0':        'gemini-2.0-flash-exp',
      'claude-3-5-sonnet': 'claude-3-5-sonnet-20241022',
      'claude-3-opus':     'claude-3-opus-20240229',
      'claude-3-haiku':    'claude-3-haiku-20240307',
    };
    return modelMap[target] ?? (providerName === 'gemini' ? 'gemini-1.5-flash' : 'gpt-4o-mini');
  }
}

export const providerRegistry = new AIProviderRegistry();
