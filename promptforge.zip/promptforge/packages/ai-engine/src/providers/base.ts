import type { TargetModel } from '@promptforge/config';

export interface CompletionResult {
  text: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
}

export interface AIProvider {
  name: string;
  complete(
    systemPrompt: string,
    userPrompt: string,
    model?: string,
  ): Promise<CompletionResult>;
  isAvailable(): boolean;
}
