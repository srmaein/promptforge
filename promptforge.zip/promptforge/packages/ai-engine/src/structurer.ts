import type { PromptStructure } from '@promptforge/types';

export function parseStructure(optimizedPrompt: string): PromptStructure {
  const text = optimizedPrompt.toLowerCase();

  const hasRole = /\b(you are|act as|as a|role:|persona:)\b/i.test(optimizedPrompt);
  const hasContext = /\b(context:|background:|given that|assuming)\b/i.test(optimizedPrompt);
  const hasTask = /\b(task:|your task|goal:|objective:|you (will|must|should))\b/i.test(optimizedPrompt);
  const hasFormat = /\b(format:|output:|respond with|return a|structure your)\b/i.test(optimizedPrompt);
  const hasConstraints = /\b(do not|avoid|must not|limit to|maximum|only)\b/i.test(optimizedPrompt);

  // Classify prompt type
  let type: PromptStructure['type'] = 'general';
  if (/\b(write|draft|create|compose|generate)\b/i.test(optimizedPrompt)) type = 'instruction';
  else if (/\?/.test(optimizedPrompt) && optimizedPrompt.split('?').length <= 3) type = 'qa';
  else if (/\b(step[- ]by[- ]step|chain of thought|think through|reason)\b/i.test(optimizedPrompt)) type = 'chain-of-thought';
  else if (/\b(code|function|implement|debug|refactor|write a (function|class|script))\b/i.test(optimizedPrompt)) type = 'code';
  else if (/\b(story|poem|creative|imagine|write a (story|poem|narrative))\b/i.test(optimizedPrompt)) type = 'creative';

  return { hasRole, hasContext, hasTask, hasFormat, hasConstraints, type };
}
