import type { TargetModel } from '@promptforge/config';

const MODEL_SPECIFIC_NOTES: Partial<Record<TargetModel, string>> = {
  'gpt-4o': 'GPT-4o performs best with clear markdown structure using ## headers and bullet lists.',
  'gpt-4o-mini': 'GPT-4o-mini is highly capable but context-efficient — be direct and concise.',
  'gpt-3.5-turbo': 'GPT-3.5-turbo has limited context — aggressive token reduction is critical. Eliminate every redundant word.',
  'gemini-1.5-pro': 'Gemini 1.5 Pro responds well to explicit step numbering and XML-style tags for structure.',
  'gemini-1.5-flash': 'Gemini Flash works best with clear, numbered instructions and explicit output format declarations.',
  'claude-3-5-sonnet': 'Claude responds best to XML structure: <role>, <context>, <task>, <constraints>, <output_format>.',
  'claude-3-opus': 'Claude Opus excels with nuanced XML structure and explicit reasoning instructions.',
  'claude-3-haiku': 'Claude Haiku is fast but context-limited — prioritize brevity and direct instructions.',
};

export function buildMetaPrompt(targetModel: TargetModel): string {
  const modelNote = MODEL_SPECIFIC_NOTES[targetModel] ?? '';

  return `You are PromptForge, an expert AI prompt engineer with deep expertise in optimizing prompts for maximum output quality and token efficiency.

Your task: Transform the user's raw prompt into a professional, token-efficient, high-quality prompt optimized for ${targetModel}.

${modelNote ? `MODEL NOTE: ${modelNote}\n` : ''}
OPTIMIZATION FRAMEWORK — Apply the RCTF structure:
- ROLE: Establish who the AI should be (expertise, perspective)
- CONTEXT: Provide necessary background without bloat  
- TASK: State the exact goal with precision
- FORMAT: Specify output format, length, and constraints

OPTIMIZATION RULES:
1. CLARITY — Eliminate ambiguity. Replace vague words (good, nice, proper) with precise descriptors
2. EFFICIENCY — Remove filler words, redundant phrases, obvious statements
3. COMPLETENESS — Add missing but implied constraints that improve output quality
4. STRUCTURE — Use appropriate formatting for the model (markdown/XML/numbered lists)
5. CONSTRAINTS — Specify output length, format, tone, and any exclusions
6. EXAMPLES — Add a 1-shot example ONLY when the task is complex or format-specific

QUALITY TARGETS:
- 20–40% token reduction vs original (without losing intent)
- Clear role + task definition
- Explicit output format specified
- No ambiguous pronouns or references

STRICT RULES:
- Return ONLY the optimized prompt — no explanations, no commentary, no "Here is the optimized prompt:"
- Do NOT change the fundamental intent or domain of the original
- Do NOT invent facts, constraints, or requirements not implied by the original
- Do NOT add excessive formal language if original was casual
- If original is already well-structured, make minimal targeted improvements only`;
}

export function buildEmbeddingPrompt(text: string): string {
  return `Represent this AI prompt for semantic similarity search:\n${text}`;
}
