import type { TargetModel } from '@promptforge/config';

interface ScoreInput {
  original: string;
  optimized: string;
  originalTokens: number;
  optimizedTokens: number;
  targetModel?: TargetModel;
}

const STOP_WORDS = new Set([
  'about', 'above', 'after', 'again', 'against', 'could', 'would', 'should',
  'there', 'their', 'these', 'those', 'which', 'while', 'where', 'please',
  'write', 'create', 'generate', 'provide', 'given', 'using', 'based', 'make',
  'help', 'need', 'want', 'like', 'also', 'just', 'very', 'really', 'quite',
]);

function extractKeywords(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 4 && !STOP_WORDS.has(w))
    .slice(0, 25);
}

export function scorePrompt(input: ScoreInput): number {
  const { original, optimized, originalTokens, optimizedTokens } = input;

  // 1. EFFICIENCY (0–30): Reward 20-40% reduction, penalize growth
  let efficiency = 0;
  const savingsPct = ((originalTokens - optimizedTokens) / Math.max(originalTokens, 1)) * 100;
  if (savingsPct >= 35)      efficiency = 30;
  else if (savingsPct >= 25) efficiency = 27;
  else if (savingsPct >= 15) efficiency = 23;
  else if (savingsPct >= 5)  efficiency = 18;
  else if (savingsPct >= 0)  efficiency = 12;
  else if (savingsPct >= -10) efficiency = 6; // slight growth can be OK
  else efficiency = 0;

  // 2. STRUCTURE (0–30): RCTF framework markers
  const lc = optimized.toLowerCase();
  const hasRole    = /\b(you are|act as|as a|role:|persona:)\b/i.test(optimized);
  const hasTask    = /\b(task:|your task|goal:|objective:|you (will|must|should) (write|create|analyze|generate|provide))\b/i.test(optimized);
  const hasFormat  = /\b(format:|output:|respond (with|in)|return (a|an|the)|structure your)\b/i.test(optimized);
  const hasContext = /\b(context:|background:|given (that|the|this)|assume)\b/i.test(optimized);
  const hasConstraints = /\b(do not|don't|avoid|must not|should not|limit to|maximum|minimum|only)\b/i.test(optimized);
  const structure = (hasRole ? 8 : 0) + (hasTask ? 8 : 0) + (hasFormat ? 6 : 0) + (hasContext ? 4 : 0) + (hasConstraints ? 4 : 0);

  // 3. COMPLETENESS (0–25): Key intent preserved
  const originalKws = extractKeywords(original);
  const preserved = originalKws.filter(kw => lc.includes(kw)).length;
  const completeness = Math.round((preserved / Math.max(originalKws.length, 1)) * 25);

  // 4. FORMATTING (0–15): Appropriate use of structure
  const isSubstantial = optimized.length > 200;
  let formatting = 0;
  if (isSubstantial) {
    const hasHeaders = /^#{1,3} .+/m.test(optimized);
    const hasBullets = /^[\-\*\d] .+/m.test(optimized);
    const hasXml = /<(role|context|task|format|constraints)>/i.test(optimized);
    formatting = (hasHeaders || hasXml ? 5 : 0) + (hasBullets ? 5 : 0) + 5;
  } else {
    // Short focused prompts don't need heavy formatting
    const hasAnyStructure = hasRole || hasTask || hasFormat;
    formatting = hasAnyStructure ? 15 : 10;
  }

  const total = Math.min(100, Math.max(0, efficiency + structure + completeness + formatting));

  return total;
}
