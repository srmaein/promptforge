import { Queue } from 'bullmq';
import { getConnection } from './connection';
import type { ForgeJobData, EmailJobData, AnalyticsJobData, ReferralJobData } from '@promptforge/types';

const defaultOptions = {
  attempts: 3,
  backoff: { type: 'exponential' as const, delay: 2000 },
  removeOnComplete: { age: 3600, count: 1000 },
  removeOnFail: { age: 86400, count: 5000 },
};

export const forgeQueue = new Queue<ForgeJobData>('forge', {
  connection: getConnection(),
  defaultJobOptions: {
    ...defaultOptions,
    attempts: 3,
    timeout: 60_000, // 60s max per AI job
  },
});

export const emailQueue = new Queue<EmailJobData>('email', {
  connection: getConnection(),
  defaultJobOptions: {
    ...defaultOptions,
    attempts: 5,
  },
});

export const analyticsQueue = new Queue<AnalyticsJobData>('analytics', {
  connection: getConnection(),
  defaultJobOptions: {
    ...defaultOptions,
    attempts: 2,
    removeOnComplete: true,
  },
});

export const referralQueue = new Queue<ReferralJobData>('referral', {
  connection: getConnection(),
  defaultJobOptions: defaultOptions,
});

export const exportQueue = new Queue('export', {
  connection: getConnection(),
  defaultJobOptions: {
    ...defaultOptions,
    timeout: 300_000, // 5 min for bulk exports
  },
});
