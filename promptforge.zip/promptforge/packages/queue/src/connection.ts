import { Redis } from 'ioredis';

let _connection: Redis | null = null;

export function getConnection(): Redis {
  if (!_connection) {
    const url = process.env.REDIS_URL ?? process.env.UPSTASH_REDIS_REST_URL;
    if (!url) throw new Error('REDIS_URL or UPSTASH_REDIS_REST_URL required for BullMQ');

    _connection = new Redis(url, {
      maxRetriesPerRequest: null, // Required by BullMQ
      enableReadyCheck: false,
      lazyConnect: true,
    });

    _connection.on('error', (err) => {
      console.error('Redis connection error:', err);
    });
  }
  return _connection;
}
