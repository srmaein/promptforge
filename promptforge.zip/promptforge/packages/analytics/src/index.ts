import { PostHog } from 'posthog-node';
import { logger } from '@promptforge/logger';

let _client: PostHog | null = null;

function getClient(): PostHog | null {
  if (!process.env.POSTHOG_API_KEY) return null;
  if (!_client) {
    _client = new PostHog(process.env.POSTHOG_API_KEY, {
      host: 'https://app.posthog.com',
      flushAt: 20,
      flushInterval: 10_000,
    });
  }
  return _client;
}

export type AnalyticsEvent =
  | 'optimization_complete'
  | 'optimization_failed'
  | 'plan_upgraded'
  | 'plan_canceled'
  | 'share_created'
  | 'template_used'
  | 'template_published'
  | 'referral_clicked'
  | 'referral_completed'
  | 'extension_installed'
  | 'extension_used';

export function track(
  userId: string,
  event: AnalyticsEvent,
  properties?: Record<string, unknown>,
): void {
  const client = getClient();
  if (!client) return;

  client.capture({
    distinctId: userId,
    event,
    properties: {
      ...properties,
      $timestamp: new Date().toISOString(),
    },
  });
}

export function identify(
  userId: string,
  traits: Record<string, unknown>,
): void {
  const client = getClient();
  if (!client) return;

  client.identify({ distinctId: userId, properties: traits });
}

export async function shutdown(): Promise<void> {
  await _client?.shutdown();
}
