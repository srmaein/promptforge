export type { TargetModel, PlanType } from '@promptforge/config';

// ─── Optimization ──────────────────────────────────
export interface OptimizationInput {
  prompt: string;
  targetModel: TargetModel;
  userId: string;
  tier: PlanType;
}

export interface PromptStructure {
  hasRole: boolean;
  hasContext: boolean;
  hasTask: boolean;
  hasFormat: boolean;
  hasConstraints: boolean;
  type: 'instruction' | 'qa' | 'chain-of-thought' | 'code' | 'creative' | 'general';
}

export interface OptimizationResult {
  optimized: string;
  originalTokens: number;
  optimizedTokens: number;
  savingsPct: number;
  score: number;
  provider: string;
  model: string;
  structure: PromptStructure;
  latencyMs: number;
  fromCache: boolean;
}

// ─── Database Entities ─────────────────────────────
export interface User {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  plan: PlanType;
  subscription_status: SubscriptionStatus | null;
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  referral_code: string;
  referred_by: string | null;
  referral_count: number;
  onboarded_at: string | null;
  created_at: string;
  updated_at: string;
}

export type SubscriptionStatus =
  | 'active'
  | 'trialing'
  | 'past_due'
  | 'canceled'
  | 'paused';

export interface PromptOptimization {
  id: string;
  user_id: string;
  original_prompt: string;
  optimized_prompt: string;
  original_tokens: number;
  optimized_tokens: number;
  savings_pct: number;
  target_model: TargetModel;
  quality_score: number;
  structure_type: string | null;
  share_id: string | null;
  is_public: boolean;
  is_starred: boolean;
  title: string | null;
  tags: string[];
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface UsageRecord {
  id: string;
  user_id: string;
  month_key: string;
  optimizations_used: number;
  optimizations_limit: number;
  tokens_processed: number;
  api_calls: number;
  created_at: string;
  updated_at: string;
}

export interface Template {
  id: string;
  author_id: string;
  title: string;
  description: string;
  template_body: string;
  variables: TemplateVariable[];
  category: string;
  target_models: TargetModel[];
  tags: string[];
  is_published: boolean;
  is_featured: boolean;
  use_count: number;
  like_count: number;
  slug: string;
  created_at: string;
  updated_at: string;
}

export interface TemplateVariable {
  name: string;
  description: string;
  required: boolean;
  default?: string;
}

// ─── Queue Jobs ─────────────────────────────────────
export interface ForgeJobData {
  prompt: string;
  targetModel: TargetModel;
  userId: string;
  plan: PlanType;
  optimizationId?: string;
}

export interface EmailJobData {
  type:
    | 'welcome'
    | 'subscription_canceled'
    | 'payment_receipt'
    | 'payment_failed'
    | 'referral_reward'
    | 'usage_limit_warning';
  userId: string;
  metadata?: Record<string, unknown>;
}

export interface AnalyticsJobData {
  event: string;
  userId: string;
  anonymousId?: string;
  properties?: Record<string, unknown>;
}

export interface ReferralJobData {
  userId: string;
  action: 'check_activation' | 'process_reward';
}

// ─── API Responses ──────────────────────────────────
export interface ApiResponse<T = unknown> {
  data?: T;
  error?: string;
  code?: string;
}

export interface ForgeApiResponse {
  optimization: PromptOptimization;
  result: OptimizationResult;
}

export interface UsageApiResponse {
  used: number;
  limit: number;
  remaining: number;
  month: string;
  resetAt: string;
}

// ─── Chrome Extension ────────────────────────────────
export type ExtMessageType =
  | 'OPTIMIZE'
  | 'GET_USER'
  | 'SET_TOKEN'
  | 'SIGN_OUT'
  | 'OPEN_POPUP'
  | 'SHOW_OPTIMIZER';

export interface ExtMessage {
  type: ExtMessageType;
  prompt?: string;
  model?: TargetModel;
  token?: string;
  selectedText?: string;
}

export interface ExtResponse {
  success: boolean;
  data?: unknown;
  error?: string;
}
