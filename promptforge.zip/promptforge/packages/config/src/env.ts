import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'staging', 'production']).default('development'),
  NEXT_PUBLIC_APP_URL: z.string().url().default('http://localhost:3000'),
  APP_SECRET: z.string().min(32),

  // Supabase
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string(),
  SUPABASE_SERVICE_ROLE_KEY: z.string(),

  // Redis
  UPSTASH_REDIS_REST_URL: z.string().url(),
  UPSTASH_REDIS_REST_TOKEN: z.string(),

  // AI Providers
  OPENAI_API_KEY: z.string().startsWith('sk-'),
  GEMINI_API_KEY: z.string(),
  ANTHROPIC_API_KEY: z.string().optional(),

  // Stripe
  STRIPE_SECRET_KEY: z.string().startsWith('sk_'),
  STRIPE_WEBHOOK_SECRET: z.string().startsWith('whsec_'),
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY: z.string().startsWith('pk_'),
  STRIPE_PRO_MONTHLY_PRICE_ID: z.string(),
  STRIPE_PRO_YEARLY_PRICE_ID: z.string(),
  STRIPE_TEAM_MONTHLY_PRICE_ID: z.string(),

  // Email
  RESEND_API_KEY: z.string(),
  EMAIL_FROM: z.string().email().default('noreply@promptforge.com'),

  // Monitoring
  SENTRY_DSN: z.string().url().optional(),
  POSTHOG_API_KEY: z.string().optional(),
});

export type Env = z.infer<typeof envSchema>;

function validateEnv(): Env {
  const result = envSchema.safeParse(process.env);
  if (!result.success) {
    console.error('❌ Invalid environment variables:');
    console.error(JSON.stringify(result.error.flatten().fieldErrors, null, 2));
    if (process.env.NODE_ENV === 'production') {
      process.exit(1);
    }
  }
  return (result.success ? result.data : {}) as Env;
}

export const env = validateEnv();
