export type PlanType = 'free' | 'pro' | 'team' | 'enterprise';
export type TargetModel =
  | 'gpt-4o'
  | 'gpt-4o-mini'
  | 'gpt-4-turbo'
  | 'gpt-3.5-turbo'
  | 'gemini-1.5-pro'
  | 'gemini-1.5-flash'
  | 'gemini-2.0'
  | 'claude-3-5-sonnet'
  | 'claude-3-opus'
  | 'claude-3-haiku'
  | 'llama-3'
  | 'mistral-large'
  | 'general';

export const ALL_MODELS: TargetModel[] = [
  'gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo',
  'gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-2.0',
  'claude-3-5-sonnet', 'claude-3-opus', 'claude-3-haiku',
  'llama-3', 'mistral-large', 'general',
];

export interface PlanConfig {
  optimizationsPerMonth: number;
  allowedModels: TargetModel[] | 'ALL';
  maxPromptTokens: number;
  historyDays: number;
  canPublishTemplates: boolean;
  maxPublishedTemplates: number;
  canShare: boolean;
  apiAccess: boolean;
  priorityQueue: boolean;
  canExport: boolean;
}

export const PLAN_LIMITS: Record<PlanType, PlanConfig> = {
  free: {
    optimizationsPerMonth: 25,
    allowedModels: ['gpt-3.5-turbo', 'gemini-1.5-flash', 'general'],
    maxPromptTokens: 2_000,
    historyDays: 7,
    canPublishTemplates: false,
    maxPublishedTemplates: 0,
    canShare: false,
    apiAccess: false,
    priorityQueue: false,
    canExport: false,
  },
  pro: {
    optimizationsPerMonth: 500,
    allowedModels: [
      'gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo',
      'gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-2.0',
      'claude-3-5-sonnet', 'claude-3-haiku', 'general',
    ],
    maxPromptTokens: 8_000,
    historyDays: Infinity,
    canPublishTemplates: true,
    maxPublishedTemplates: 10,
    canShare: true,
    apiAccess: false,
    priorityQueue: false,
    canExport: true,
  },
  team: {
    optimizationsPerMonth: Infinity,
    allowedModels: 'ALL',
    maxPromptTokens: 32_000,
    historyDays: Infinity,
    canPublishTemplates: true,
    maxPublishedTemplates: Infinity,
    canShare: true,
    apiAccess: true,
    priorityQueue: true,
    canExport: true,
  },
  enterprise: {
    optimizationsPerMonth: Infinity,
    allowedModels: 'ALL',
    maxPromptTokens: 128_000,
    historyDays: Infinity,
    canPublishTemplates: true,
    maxPublishedTemplates: Infinity,
    canShare: true,
    apiAccess: true,
    priorityQueue: true,
    canExport: true,
  },
};

export function isModelAllowed(model: TargetModel, plan: PlanType): boolean {
  const allowed = PLAN_LIMITS[plan].allowedModels;
  if (allowed === 'ALL') return true;
  return allowed.includes(model);
}
