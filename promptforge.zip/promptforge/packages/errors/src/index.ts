export class AppError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode: number = 500,
    public readonly isOperational: boolean = true,
  ) {
    super(message);
    this.name = 'AppError';
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

export class ValidationError extends AppError {
  constructor(message: string) {
    super('VALIDATION_ERROR', message, 400);
    this.name = 'ValidationError';
  }
}

export class AuthError extends AppError {
  constructor(message = 'Unauthorized') {
    super('UNAUTHORIZED', message, 401);
    this.name = 'AuthError';
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'Forbidden') {
    super('FORBIDDEN', message, 403);
    this.name = 'ForbiddenError';
  }
}

export class PlanGateError extends AppError {
  constructor(public readonly requiredPlan: string) {
    super('PLAN_REQUIRED', `This feature requires the ${requiredPlan} plan`, 403);
    this.name = 'PlanGateError';
  }
}

export class UsageLimitError extends AppError {
  constructor(
    public readonly used: number,
    public readonly limit: number,
  ) {
    super('USAGE_LIMIT_EXCEEDED', 'Monthly optimization limit reached', 429);
    this.name = 'UsageLimitError';
  }
}

export class OptimizationError extends AppError {
  constructor(code: string, message: string) {
    super(code, message, 422);
    this.name = 'OptimizationError';
  }
}

export class RateLimitError extends AppError {
  constructor(public readonly retryAfter: number = 60) {
    super('RATE_LIMITED', 'Too many requests', 429);
    this.name = 'RateLimitError';
  }
}

export class NotFoundError extends AppError {
  constructor(resource = 'Resource') {
    super('NOT_FOUND', `${resource} not found`, 404);
    this.name = 'NotFoundError';
  }
}

export class ConflictError extends AppError {
  constructor(message: string) {
    super('CONFLICT', message, 409);
    this.name = 'ConflictError';
  }
}

export class BudgetExceededError extends AppError {
  constructor() {
    super('BUDGET_EXCEEDED', 'Service temporarily throttled due to high demand', 503);
    this.name = 'BudgetExceededError';
  }
}

export function handleApiError(err: unknown): Response {
  if (err instanceof AppError && err.isOperational) {
    const body: Record<string, unknown> = {
      error: err.message,
      code: err.code,
    };
    if (err instanceof PlanGateError) body.requiredPlan = err.requiredPlan;
    if (err instanceof UsageLimitError) {
      body.used = err.used;
      body.limit = err.limit;
      body.upgradeRequired = true;
    }
    return Response.json(body, { status: err.statusCode });
  }

  console.error('Unhandled error:', err);
  return Response.json({ error: 'An unexpected error occurred' }, { status: 500 });
}

export function isAppError(err: unknown): err is AppError {
  return err instanceof AppError;
}
