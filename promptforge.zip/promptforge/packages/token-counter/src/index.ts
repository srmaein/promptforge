import { get_encoding, type Tiktoken } from 'js-tiktoken';
import type { TargetModel } from '@promptforge/config';

type EncodingName = 'o200k_base' | 'cl100k_base' | 'p50k_base';

const OPENAI_ENCODING_MAP: Partial<Record<TargetModel, EncodingName>> = {
  'gpt-4o':         'o200k_base',
  'gpt-4o-mini':    'o200k_base',
  'gpt-4-turbo':    'cl100k_base',
  'gpt-3.5-turbo':  'cl100k_base',
};

// Non-OpenAI models use character-based approximation
const CHARS_PER_TOKEN: Partial<Record<TargetModel, number>> = {
  'gemini-1.5-pro':    4.0,
  'gemini-1.5-flash':  4.0,
  'gemini-2.0':        4.0,
  'claude-3-5-sonnet': 3.5,
  'claude-3-opus':     3.5,
  'claude-3-haiku':    3.5,
  'llama-3':           3.8,
  'mistral-large':     3.8,
  'general':           4.0,
};

// Cost per 1K tokens (input) in USD
const COST_PER_1K: Partial<Record<TargetModel, number>> = {
  'gpt-4o':            0.005,
  'gpt-4o-mini':       0.00015,
  'gpt-4-turbo':       0.01,
  'gpt-3.5-turbo':     0.0005,
  'gemini-1.5-flash':  0.000075,
  'gemini-1.5-pro':    0.00125,
  'gemini-2.0':        0.000075,
  'claude-3-5-sonnet': 0.003,
  'claude-3-opus':     0.015,
  'claude-3-haiku':    0.00025,
};

export class TokenCounter {
  private encoders: Map<EncodingName, Tiktoken> = new Map();

  count(text: string, model: TargetModel = 'general'): number {
    const encodingName = OPENAI_ENCODING_MAP[model];

    if (encodingName) {
      if (!this.encoders.has(encodingName)) {
        this.encoders.set(encodingName, get_encoding(encodingName));
      }
      return this.encoders.get(encodingName)!.encode(text).length;
    }

    // Approximate for non-OpenAI models
    const charsPerToken = CHARS_PER_TOKEN[model] ?? 4.0;
    return Math.ceil(text.length / charsPerToken);
  }

  // Quick rough estimate without loading tiktoken (used for plan checks)
  roughCount(text: string): number {
    return Math.ceil(text.length / 4);
  }

  estimateCostUsd(tokens: number, model: TargetModel): number {
    const rate = COST_PER_1K[model] ?? 0.001;
    return (tokens / 1000) * rate;
  }

  // Token savings as a formatted string
  formatSavings(original: number, optimized: number): string {
    const saved = original - optimized;
    const pct = Math.round((saved / original) * 100);
    return `−${saved} tokens (${pct}%)`;
  }

  cleanup() {
    for (const enc of this.encoders.values()) {
      enc.free();
    }
    this.encoders.clear();
  }
}

// Singleton for app-wide use
export const tokenCounter = new TokenCounter();
