import { getStripe } from './client';
import { db } from '@promptforge/db';
import { logger } from '@promptforge/logger';

export async function getOrCreateCustomer(
  userId: string,
  email: string,
  name?: string,
): Promise<string> {
  const stripe = getStripe();

  // Check if already have a customer ID
  const { data: user } = await db
    .from('users')
    .select('stripe_customer_id')
    .eq('id', userId)
    .single();

  if (user?.stripe_customer_id) return user.stripe_customer_id;

  const customer = await stripe.customers.create({
    email,
    name: name ?? undefined,
    metadata: { userId },
  });

  await db.from('users').update({ stripe_customer_id: customer.id }).eq('id', userId);

  logger.info({ event: 'stripe_customer_created', userId, customerId: customer.id });
  return customer.id;
}

export async function createCheckoutSession(params: {
  userId: string;
  email: string;
  name?: string;
  priceId: string;
  successUrl: string;
  cancelUrl: string;
}): Promise<string> {
  const stripe = getStripe();
  const customerId = await getOrCreateCustomer(params.userId, params.email, params.name);

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [{ price: params.priceId, quantity: 1 }],
    success_url: params.successUrl,
    cancel_url: params.cancelUrl,
    subscription_data: {
      trial_period_days: 7,
      metadata: { userId: params.userId },
    },
    allow_promotion_codes: true,
    billing_address_collection: 'auto',
    metadata: { userId: params.userId },
  });

  if (!session.url) throw new Error('No checkout URL returned');
  return session.url;
}

export async function createPortalSession(
  customerId: string,
  returnUrl: string,
): Promise<string> {
  const stripe = getStripe();
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });
  return session.url;
}
