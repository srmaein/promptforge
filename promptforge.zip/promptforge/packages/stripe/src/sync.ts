import type Stripe from 'stripe';
import { db } from '@promptforge/db';
import { getMonthKey } from '@promptforge/db';
import { cache, RedisKeys } from '@promptforge/redis';
import { logger } from '@promptforge/logger';

function getPriceMap(): Record<string, string> {
  return {
    [process.env.STRIPE_PRO_MONTHLY_PRICE_ID ?? '']: 'pro',
    [process.env.STRIPE_PRO_YEARLY_PRICE_ID ?? '']: 'pro',
    [process.env.STRIPE_TEAM_MONTHLY_PRICE_ID ?? '']: 'team',
  };
}

export async function syncSubscription(sub: Stripe.Subscription): Promise<void> {
  const userId = sub.metadata?.userId;
  if (!userId) {
    logger.warn({ event: 'subscription_no_userid', subscriptionId: sub.id });
    return;
  }

  const priceMap = getPriceMap();
  const priceId = sub.items.data[0]?.price?.id ?? '';
  const plan = priceMap[priceId] ?? 'free';

  await db.from('users').update({
    plan: plan as 'free' | 'pro' | 'team',
    subscription_status: sub.status as 'active' | 'trialing' | 'past_due' | 'canceled' | 'paused',
    stripe_subscription_id: sub.id,
  }).eq('id', userId);

  await cache.del(RedisKeys.userPlanCache(userId));

  // Sync usage limit for current month
  const limitMap: Record<string, number> = { pro: 500, team: 999999, free: 25 };
  await db.from('usage_records').upsert(
    {
      user_id: userId,
      month_key: getMonthKey(),
      optimizations_limit: limitMap[plan] ?? 25,
    },
    { onConflict: 'user_id,month_key', ignoreDuplicates: true },
  );

  logger.info({ event: 'subscription_synced', userId, plan, status: sub.status });
}

export async function downgradeToFree(sub: Stripe.Subscription): Promise<void> {
  const userId = sub.metadata?.userId;
  if (!userId) return;

  await db.from('users').update({
    plan: 'free',
    subscription_status: 'canceled',
    stripe_subscription_id: null,
  }).eq('id', userId);

  await cache.del(RedisKeys.userPlanCache(userId));
  logger.info({ event: 'subscription_downgraded', userId });
}
