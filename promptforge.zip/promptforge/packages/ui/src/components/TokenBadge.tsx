import React from 'react';

interface TokenBadgeProps {
  original: number;
  optimized: number;
}

export function TokenBadge({ original, optimized }: TokenBadgeProps) {
  const saved = original - optimized;
  const pct = Math.round((saved / original) * 100);
  const isPositive = saved > 0;

  return (
    <div className="flex items-center gap-2 text-sm">
      <span className="text-gray-500 line-through">{original.toLocaleString()} tokens</span>
      <span className="text-gray-400">→</span>
      <span className="font-medium">{optimized.toLocaleString()} tokens</span>
      {isPositive && (
        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
          −{pct}%
        </span>
      )}
    </div>
  );
}
