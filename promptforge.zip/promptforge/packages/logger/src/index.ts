import pino, { type Logger } from 'pino';

const isDev = process.env.NODE_ENV !== 'production';

export const logger: Logger = pino({
  level: isDev ? 'debug' : 'info',
  transport: isDev
    ? {
        target: 'pino-pretty',
        options: {
          colorize: true,
          ignore: 'pid,hostname',
          translateTime: 'SYS:HH:MM:ss',
        },
      }
    : undefined,
  formatters: {
    level: (label) => ({ level: label }),
  },
  base: {
    service: 'promptforge',
    env: process.env.NODE_ENV,
    version: process.env.npm_package_version ?? '1.0.0',
  },
  redact: {
    paths: [
      'token',
      'authorization',
      'password',
      'api_key',
      '*.api_key',
      'body.token',
      'headers.authorization',
      'headers.cookie',
    ],
    censor: '[REDACTED]',
  },
  serializers: {
    err: pino.stdSerializers.err,
    req: pino.stdSerializers.req,
    res: pino.stdSerializers.res,
  },
});

export function createChildLogger(context: Record<string, unknown>): Logger {
  return logger.child(context);
}

export function createRequestLogger(requestId: string, method: string, path: string): Logger {
  return logger.child({ requestId, method, path });
}

export type { Logger };
