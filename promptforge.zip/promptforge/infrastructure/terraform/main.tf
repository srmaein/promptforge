terraform {
  required_providers {
    vercel = {
      source  = "vercel/vercel"
      version = "~> 1.0"
    }
  }
  backend "remote" {
    organization = "promptforge"
    workspaces { name = "production" }
  }
}

provider "vercel" {
  api_token = var.vercel_api_token
}

variable "vercel_api_token" {
  description = "Vercel API token"
  type        = string
  sensitive   = true
}

variable "github_repo" {
  description = "GitHub repo (org/repo)"
  type        = string
  default     = "your-org/promptforge"
}

resource "vercel_project" "web" {
  name           = "promptforge"
  framework      = "nextjs"
  root_directory = "apps/web"
  git_repository = {
    repo = var.github_repo
    type = "github"
  }
  build_command   = "cd ../.. && pnpm turbo build --filter=@promptforge/web..."
  install_command = "cd ../.. && pnpm install --frozen-lockfile"
  output_directory = ".next"
  serverless_function_region = "iad1"
}

resource "vercel_project_domain" "apex" {
  project_id = vercel_project.web.id
  domain     = "promptforge.ai"
}

resource "vercel_project_domain" "www" {
  project_id  = vercel_project.web.id
  domain      = "www.promptforge.ai"
  redirect    = "promptforge.ai"
  redirect_status_code = 308
}

output "deployment_url" {
  value = vercel_project.web.id
}
